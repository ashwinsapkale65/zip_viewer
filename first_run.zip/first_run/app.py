import os
import re
import json
import hashlib
import tempfile
import httpx
import streamlit as st
from io import BytesIO
from datetime import datetime
from dotenv import load_dotenv
from typing import Callable, Any

from pdfminer.high_level import extract_text
from docx import Document
from PIL import Image
import pytesseract
import fitz
import io
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether, PageBreak
)
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT

# =========================================================
# CONFIGURATION
# =========================================================

load_dotenv()
api_key = os.getenv("API_KEY")
os.environ["TIKTOKEN_CACHE_DIR"] = "./token"
client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=api_key,
    http_client=client,
    temperature=0
)

embedding_model = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=api_key,
    http_client=client
)

HASH_STORE_PATH = "./compliance_index/doc_hashes.json"

# =========================================================
# MARKDOWN STRIPPER  — plain text for PDF rendering
# =========================================================

def strip_markdown(text: str) -> str:
    """
    Removes common markdown syntax so the PDF contains clean plain text.
    Handles: headers (#), bold (**), italic (*/_), inline code (`),
    fenced code blocks (```), horizontal rules (---/===), hyperlinks,
    and leading/trailing whitespace per line.
    """
    # fenced code blocks
    text = re.sub(r"```[^\n]*\n.*?```", "", text, flags=re.DOTALL)
    # headers
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.MULTILINE)
    # bold + italic  ***text***  or  ___text___
    text = re.sub(r"\*{1,3}(.+?)\*{1,3}", r"\1", text)
    text = re.sub(r"_{1,3}(.+?)_{1,3}", r"\1", text)
    # inline code
    text = re.sub(r"`(.+?)`", r"\1", text)
    # markdown links  [text](url)
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    # horizontal rules
    text = re.sub(r"^[-*_]{3,}\s*$", "", text, flags=re.MULTILINE)
    # blockquotes
    text = re.sub(r"^>\s?", "", text, flags=re.MULTILINE)
    # collapse 3+ blank lines to 2
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# =========================================================
# AGENT REGISTRY
# =========================================================

AGENT_REGISTRY = [
    {"id": "extractor",  "name": "Document Extractor",   "icon": "📄",
     "description": "Parses and extracts raw text from PDF, DOCX, or TXT files",
     "role": "File Parser"},
    {"id": "validator",  "name": "Compliance Validator",  "icon": "🔍",
     "description": "Verifies the document is a genuine compliance or governance document",
     "role": "Document Classifier"},
    {"id": "dedup",      "name": "Deduplication Agent",   "icon": "🔁",
     "description": "Checks if document is identical to the stored company standard via hash",
     "role": "Hash Comparator"},
    {"id": "retriever",  "name": "Context Retriever",     "icon": "🗂️",
     "description": "Retrieves relevant chunks from the company vector store via RAG",
     "role": "RAG Retriever"},
    {"id": "auditor",    "name": "Compliance Auditor",    "icon": "⚖️",
     "description": "Performs deep compliance gap analysis and risk assessment via LLM",
     "role": "LLM Auditor"},
    {"id": "optimizer",  "name": "Policy Optimizer",      "icon": "🛠️",
     "description": "Rewrites the user document to be fully compliant — fills gaps, adds missing clauses",
     "role": "Document Rewriter"},
    {"id": "reporter",   "name": "Report Generator",      "icon": "📊",
     "description": "Builds separate Audit PDF and Optimized Document PDF",
     "role": "PDF Builder"},
]

# =========================================================
# AGENT PIPELINE — live UI updater
# =========================================================

class AgentResult:
    def __init__(self, success: bool, data: Any = None, error: str = ""):
        self.success = success
        self.data    = data
        self.error   = error


class AgentPipeline:
    STATUS = {
        "idle":    ("⬜", "#4B5563", "#161B22", "Waiting"),
        "running": ("🔄", "#FBBF24", "#1C1E24", "Running"),
        "done":    ("✅", "#10B981", "#0D1F17",  "Done"),
        "error":   ("❌", "#EF4444", "#1F0D0D",  "Error"),
        "skipped": ("⏭️",  "#6B7280", "#161B22", "Skipped"),
    }

    def __init__(self, placeholder):
        self.ph       = placeholder
        self.statuses = {a["id"]: "idle" for a in AGENT_REGISTRY}
        self.messages = {a["id"]: ""     for a in AGENT_REGISTRY}
        self.results  = {}
        self._render()

    def _set(self, aid, status, msg=""):
        self.statuses[aid] = status
        self.messages[aid] = msg
        self._render()

    def run(self, agent_id, fn, *args, **kwargs):
        cfg = next(a for a in AGENT_REGISTRY if a["id"] == agent_id)
        self._set(agent_id, "running", f"Executing {cfg['name']}...")
        try:
            data   = fn(*args, **kwargs)
            result = AgentResult(True, data)
            self._set(agent_id, "done", "Completed successfully")
        except Exception as e:
            result = AgentResult(False, error=str(e))
            self._set(agent_id, "error", str(e)[:120])
        self.results[agent_id] = result
        return result

    def skip(self, agent_id, reason="Not required"):
        self.statuses[agent_id] = "skipped"
        self.messages[agent_id] = reason
        self.results[agent_id]  = AgentResult(True)
        self._render()

    def fail(self, agent_id, reason):
        self.statuses[agent_id] = "error"
        self.messages[agent_id] = reason
        self.results[agent_id]  = AgentResult(False, error=reason)
        self._render()

    def override_msg(self, agent_id, msg):
        self.messages[agent_id] = msg
        self._render()

    def _render(self):
        cards = ""
        for ag in AGENT_REGISTRY:
            st_key            = self.statuses[ag["id"]]
            icon_s, border, bg, label = self.STATUS[st_key]
            msg       = self.messages[ag["id"]] or label
            is_active = st_key == "running"
            pulse_css = "animation: agPulse 1.3s ease-in-out infinite;" if is_active else ""
            glow_css  = f"box-shadow: 0 0 0 2px {border}40;" if is_active else ""

            cards += f"""
            <div style="border:1.5px solid {border};border-radius:10px;padding:12px 14px;
                        background:{bg};display:flex;align-items:flex-start;gap:12px;
                        {pulse_css}{glow_css}transition:border-color 0.3s,box-shadow 0.3s;">
                <div style="font-size:22px;line-height:1.2;flex-shrink:0">{ag['icon']}</div>
                <div style="flex:1;min-width:0;overflow:hidden">
                    <div style="display:flex;justify-content:space-between;align-items:center;
                                flex-wrap:wrap;gap:6px;margin-bottom:3px">
                        <span style="font-family:'IBM Plex Mono',monospace;font-size:12.5px;
                                     font-weight:700;color:#E6EDF3;letter-spacing:0.2px">
                            {ag['name']}</span>
                        <span style="font-size:9.5px;background:#21262D;color:#8B949E;
                                     padding:2px 8px;border-radius:999px;
                                     font-family:'IBM Plex Mono',monospace;white-space:nowrap">
                            {ag['role']}</span>
                    </div>
                    <div style="font-size:10.5px;color:#8B949E;margin-bottom:5px;
                                font-family:'DM Sans',sans-serif">{ag['description']}</div>
                    <div style="font-size:10.5px;font-family:'IBM Plex Mono',monospace;
                                color:{'#FBBF24' if is_active else border};
                                white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                        {icon_s}&nbsp; {msg}</div>
                </div>
            </div>"""

        html = f"""
        <style>
          @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&family=DM+Sans:wght@400;500&display=swap');
          @keyframes agPulse {{ 0%,100%{{opacity:1}} 50%{{opacity:.75}} }}
        </style>
        <div style="background:#0D1117;border:1px solid #21262D;border-radius:14px;
                    padding:16px;margin:8px 0 4px 0;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;
                      padding-bottom:10px;border-bottom:1px solid #21262D">
            <span style="font-size:16px">🤖</span>
            <span style="font-family:'IBM Plex Mono',monospace;font-size:12px;font-weight:700;
                         color:#E6EDF3;letter-spacing:2px">AGENT PIPELINE</span>
            <span style="font-size:9px;background:#1D4ED8;color:#BFDBFE;padding:2px 9px;
                         border-radius:999px;margin-left:auto;font-family:monospace;
                         letter-spacing:1px">LIVE</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;">{cards}</div>
        </div>"""
        self.ph.markdown(html, unsafe_allow_html=True)


# =========================================================
# FILE EXTRACTION
# =========================================================

def extract_pdf_text(file_path):
    full_text = []
    try:
        pdf_document = fitz.open(file_path)
        for page_number in range(len(pdf_document)):
            page = pdf_document.load_page(page_number)
            text = page.get_text("text")
            if text and len(text.strip()) > 30:
                full_text.append(text)
            else:
                pix       = page.get_pixmap(dpi=300)
                img_bytes = pix.tobytes("png")
                image     = Image.open(io.BytesIO(img_bytes))
                ocr_text  = pytesseract.image_to_string(image)
                full_text.append(ocr_text)
        pdf_document.close()
    except Exception as e:
        return f"PDF Processing Error: {str(e)}"
    return "\n".join(full_text)

def extract_docx_text(path):
    return "\n".join(p.text for p in Document(path).paragraphs)

def extract_txt_text(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def process_uploaded_file(uploaded_file) -> str:
    suffix = uploaded_file.name.split(".")[-1].lower()
    uploaded_file.seek(0)
    with tempfile.NamedTemporaryFile(delete=False, suffix=f".{suffix}") as tmp:
        tmp.write(uploaded_file.read())
        path = tmp.name
    if suffix == "pdf":  return extract_pdf_text(path)
    if suffix == "docx": return extract_docx_text(path)
    if suffix == "txt":  return extract_txt_text(path)
    return ""

# =========================================================
# HASH STORE
# =========================================================

def compute_text_hash(text):
    return hashlib.sha256(text.strip().encode()).hexdigest()

def load_hash_store():
    if os.path.exists(HASH_STORE_PATH):
        with open(HASH_STORE_PATH) as f:
            return json.load(f)
    return {}

def save_hash_store(store):
    os.makedirs(os.path.dirname(HASH_STORE_PATH), exist_ok=True)
    with open(HASH_STORE_PATH, "w") as f:
        json.dump(store, f, indent=2)

# =========================================================
# COMPLIANCE VALIDATION
# =========================================================

STRONG_KW = [
    "compliance","regulation","regulatory","gdpr","hipaa","sox","iso 27001","iso 9001",
    "pci dss","audit","governance","internal control","data protection","code of conduct",
    "ethics policy","whistleblower","non-disclosure","confidentiality agreement",
    "terms of service","service level agreement","sla","privacy policy",
    "acceptable use policy","information security policy","risk management",
    "corrective action","disciplinary","sanctions","penalties","enforcement",
    "mandate","due diligence","third-party risk","vendor management",
]
BROAD_KW = [
    "policy","policies","procedure","procedures","standard","standards",
    "requirement","requirements","obligation","obligations","framework",
    "control","controls","risk","security","privacy","legal","clause",
    "directive","monitoring","review","assessment","violation","penalty",
    "employee","employees","conduct","responsibilities","handbook","guidelines",
    "rules","rights","duties","protection","safeguard","training","awareness",
    "incident","breach","reporting","escalation","approval","authorization",
    "access","restriction","prohibited","documentation","records","retention",
    "disposal","classification",
]
DOC_TYPES = [
    "handbook","manual","charter","policy document","code of conduct",
    "employee guide","staff guide","hr policy","compliance program",
    "operating procedure","sop","work instruction","quality manual",
]

def validate_compliance_document(text: str) -> tuple:
    low = text.lower()
    wc  = len(text.split())
    if wc < 50:
        return False, f"Document too short ({wc} words)."
    for kw in STRONG_KW:
        if kw in low: return True, ""
    for dt in DOC_TYPES:
        if dt in low: return True, ""
    broad = [k for k in BROAD_KW if k in low]
    if len(broad) >= 4: return True, ""
    excerpt = " ".join(text.split()[:600])
    try:
        resp = llm.invoke(
            f"You are a compliance document classifier. Answer ONLY YES or NO.\n\n"
            f"Is this a compliance-related document?\n\n"
            f"Answer NO only if clearly unrelated (recipe, novel, news, source code, resume).\n\n"
            f'Document:\n"""{excerpt}"""\n\nAnswer:'
        )
        if "YES" in resp.content.strip().upper(): return True, ""
    except Exception:
        return True, ""
    return False, (
        "This does not appear to be a compliance or governance document. "
        f"Broad terms matched: {broad or 'none'}."
    )

# =========================================================
# AGENT TASK FUNCTIONS
# =========================================================

def agent_extract(uploaded_file) -> str:
    text = process_uploaded_file(uploaded_file)
    if not text.strip():
        raise ValueError("No text could be extracted from the uploaded file.")
    return text

def agent_validate(text: str) -> tuple:
    return validate_compliance_document(text)

def agent_dedup(text: str, company: str) -> dict:
    h     = compute_text_hash(text)
    store = load_hash_store()
    return {"is_identical": store.get(company) == h, "hash": h}

def agent_retrieve(company: str):
    vdb = Chroma(embedding_function=embedding_model,
                 persist_directory=f"./compliance_index/{company}")
    ret = vdb.as_retriever(search_type="similarity", search_kwargs={"k": 5})
    return RetrievalQA.from_chain_type(llm=llm, retriever=ret, return_source_documents=True)

def agent_audit(rag_chain, user_text: str, company: str) -> str:
    prompt = f"""You are an enterprise compliance auditor AI.

Compare the USER compliance document against the COMPANY standard for {company}.

USER DOCUMENT:
---------------------------
{user_text}

Respond in plain text only — no markdown, no asterisks, no hashes.
Use numbered headings like:  1. Executive Summary

Sections:
1. Executive Summary
2. Compliance Gaps
3. Missing Clauses
4. Outdated or Conflicting Policies
5. Risk Severity (Critical / Major / Minor — one overall level)
6. Corrective Actions
7. Compliance Score (single number out of 100)
8. Relevance Score (single number out of 100)
"""
    result = rag_chain.invoke(prompt)
    return strip_markdown(result["result"])


def agent_optimize(user_text: str, analysis: str, company: str) -> str:
    """
    Agent 6 — Policy Optimizer.
    Rewrites the user document to be FULLY compliant.
    Output is plain text — no markdown.
    """
    prompt = f"""You are a senior compliance policy writer AI for {company}.

You have been given:
1. The ORIGINAL USER DOCUMENT that has compliance gaps.
2. The AUDIT ANALYSIS listing all gaps, missing clauses, and corrective actions.

Your task:
- Rewrite the user document to be FULLY compliant with the company standard.
- Insert all MISSING CLAUSES identified in the audit.
- Fix all OUTDATED or CONFLICTING POLICIES.
- Address every CORRECTIVE ACTION listed in the audit.
- Preserve all already-compliant content from the original document.
- Use professional, formal compliance language throughout.
- Structure the output with clear numbered section headings (e.g. 1. Purpose).
- At the very top write exactly this line: OPTIMIZED COMPLIANT DOCUMENT - Generated by AI Policy Optimizer
- At the end, add a section titled: Changes Made
  List every change and addition as plain bullet points starting with a dash (-).

IMPORTANT: Output plain text only. Do NOT use markdown, asterisks, hashes, or any special formatting.

--- ORIGINAL USER DOCUMENT ---
{user_text}

--- AUDIT ANALYSIS ---
{analysis}

--- OUTPUT: FULLY OPTIMIZED COMPLIANT DOCUMENT ---
"""
    resp = llm.invoke(prompt)
    return strip_markdown(resp.content)


def agent_store_company(text: str, company: str) -> dict:
    h     = compute_text_hash(text)
    store = load_hash_store()
    already = store.get(company) == h and os.path.exists(f"./compliance_index/{company}")
    if not already:
        chunks = RecursiveCharacterTextSplitter(
            chunk_size=1000, chunk_overlap=200
        ).split_text(text)
        vdb = Chroma.from_texts(
            chunks, embedding_model,
            persist_directory=f"./compliance_index/{company}"
        )
        vdb.persist()
        store[company] = h
        save_hash_store(store)
    return {"already_existed": already, "hash": h}


IDENTICAL_ANALYSIS = strip_markdown(
    "IDENTICAL DOCUMENT DETECTED\n\n"
    "1. Executive Summary\n"
    "The submitted document exactly matches the stored company standard. "
    "All clauses, policies, and procedures are fully aligned.\n\n"
    "2. Compliance Gaps\nNone identified. Fully compliant.\n\n"
    "3. Missing Clauses\nNone.\n\n"
    "4. Outdated or Conflicting Policies\nNone detected.\n\n"
    "5. Risk Severity\nNONE - 100% compliant.\n\n"
    "6. Corrective Actions\nNo corrective actions required.\n\n"
    "7. Compliance Score\n100 out of 100\n\n"
    "8. Relevance Score\n100 out of 100\n"
)

IDENTICAL_OPTIMIZED = (
    "OPTIMIZED COMPLIANT DOCUMENT - Generated by AI Policy Optimizer\n\n"
    "This document is already 100% compliant with the company standard.\n"
    "No changes were necessary.\n\n"
    "Changes Made\n- No changes required. Document is fully compliant."
)

# =========================================================
# COLOR + STYLE HELPERS
# =========================================================

def _bc():
    return dict(
        primary  = colors.HexColor("#1B3A6B"),
        accent   = colors.HexColor("#2D7DD2"),
        success  = colors.HexColor("#27AE60"),
        warning  = colors.HexColor("#E67E22"),
        danger   = colors.HexColor("#C0392B"),
        light_bg = colors.HexColor("#F4F7FB"),
        border   = colors.HexColor("#D0D8E8"),
        text     = colors.HexColor("#1A1A2E"),
        muted    = colors.HexColor("#6B7280"),
        white    = colors.white,
        opt_green= colors.HexColor("#EAF7EE"),
        opt_border= colors.HexColor("#A8D5B5"),
    )

def _bs():
    base = getSampleStyleSheet()
    c    = _bc()
    return dict(
        cover_title = ParagraphStyle("ct", parent=base["Title"], fontSize=26, leading=32,
                          textColor=c["white"], fontName="Helvetica-Bold",
                          alignment=TA_CENTER, spaceAfter=8),
        cover_sub   = ParagraphStyle("cs", parent=base["Normal"], fontSize=13, leading=18,
                          textColor=colors.HexColor("#B8C8E8"), fontName="Helvetica",
                          alignment=TA_CENTER, spaceAfter=4),
        cover_meta  = ParagraphStyle("cm", parent=base["Normal"], fontSize=10, leading=14,
                          textColor=colors.HexColor("#D0D8E8"), fontName="Helvetica",
                          alignment=TA_CENTER),
        # ── audit styles ────────────────────────────────────
        section_heading = ParagraphStyle("sh", parent=base["Heading1"], fontSize=13, leading=18,
                              textColor=c["primary"], fontName="Helvetica-Bold",
                              spaceBefore=14, spaceAfter=6),
        body        = ParagraphStyle("bd", parent=base["Normal"], fontSize=10, leading=15,
                          textColor=c["text"], fontName="Helvetica",
                          spaceAfter=5, alignment=TA_JUSTIFY),
        bullet      = ParagraphStyle("bl", parent=base["Normal"], fontSize=10, leading=14,
                          textColor=c["text"], fontName="Helvetica",
                          leftIndent=14, spaceAfter=3),
        risk_critical= ParagraphStyle("rc", parent=base["Normal"], fontSize=11, leading=15,
                           textColor=c["danger"], fontName="Helvetica-Bold",
                           spaceAfter=5),
        risk_major  = ParagraphStyle("rm", parent=base["Normal"], fontSize=11, leading=15,
                          textColor=c["warning"], fontName="Helvetica-Bold",
                          spaceAfter=5),
        risk_minor  = ParagraphStyle("rn", parent=base["Normal"], fontSize=11, leading=15,
                          textColor=c["success"], fontName="Helvetica-Bold",
                          spaceAfter=5),
        # ── optimized doc styles ─────────────────────────────
        opt_heading = ParagraphStyle("oh", parent=base["Heading1"], fontSize=13, leading=18,
                          textColor=colors.HexColor("#1A7A3C"), fontName="Helvetica-Bold",
                          spaceBefore=14, spaceAfter=6),
        opt_body    = ParagraphStyle("ob", parent=base["Normal"], fontSize=10, leading=15,
                          textColor=c["text"], fontName="Helvetica",
                          spaceAfter=5, alignment=TA_JUSTIFY),
        opt_bullet  = ParagraphStyle("obl", parent=base["Normal"], fontSize=10, leading=14,
                          textColor=colors.HexColor("#1A5C2E"), fontName="Helvetica",
                          leftIndent=14, spaceAfter=3),
        # ── shared ───────────────────────────────────────────
        score_label = ParagraphStyle("sl", parent=base["Normal"], fontSize=10, leading=13,
                          textColor=c["muted"], fontName="Helvetica", alignment=TA_CENTER),
        score_value = ParagraphStyle("sv", parent=base["Normal"], fontSize=26, leading=30,
                          textColor=c["primary"], fontName="Helvetica-Bold",
                          alignment=TA_CENTER),
        footer_text = ParagraphStyle("ft", parent=base["Normal"], fontSize=8,
                          textColor=c["muted"], fontName="Helvetica", alignment=TA_CENTER),
    )

def _score_col(v):
    c = _bc()
    return c["success"] if v >= 85 else c["warning"] if v >= 60 else c["danger"]

def _risk_style(text, s):
    tl = text.lower()
    if "critical" in tl: return s["risk_critical"]
    if "major"    in tl or "high" in tl: return s["risk_major"]
    return s["risk_minor"]

def _parse_scores(txt):
    comp = rel = 0
    for pat, kind in [
        (r"compliance score[^\d]*(\d{1,3})", "comp"),
        (r"relevance score[^\d]*(\d{1,3})",  "rel"),
        (r"score[^\d]*(\d{1,3})\s*/\s*100",  "comp"),
    ]:
        m = re.search(pat, txt, re.IGNORECASE)
        if m:
            v = min(int(m.group(1)), 100)
            if kind == "comp" and not comp: comp = v
            elif kind == "rel" and not rel:  rel  = v
    return comp, rel

def _parse_sections(txt):
    """Split plain text into (title, body) tuples on numbered headings."""
    lines = txt.split("\n")
    secs  = []
    title = "Analysis"
    body  = []
    for ln in lines:
        s = ln.strip()
        # match numbered heading:  "1. Title" or "1) Title"
        if re.match(r"^\d+[\.\)]\s+\S", s) and len(s) < 100:
            if body: secs.append((title, "\n".join(body).strip()))
            title = re.sub(r"^\d+[\.\)]\s+", "", s).strip()
            body  = []
        else:
            body.append(ln)
    if body: secs.append((title, "\n".join(body).strip()))
    return secs or [("Full Analysis", txt)]

# =========================================================
# COVER + FOOTER BUILDERS (shared)
# =========================================================

def _make_cover_and_footer(c):
    def cover(cv, doc):
        cv.saveState()
        cv.setFillColor(c["primary"])
        cv.rect(0, A4[1] - 220, A4[0], 220, fill=1, stroke=0)
        cv.setFillColor(c["accent"])
        cv.rect(0, A4[1] - 226, A4[0], 8, fill=1, stroke=0)
        cv.restoreState()

    def footer(cv, doc):
        cv.saveState()
        cv.setFont("Helvetica", 8)
        cv.setFillColor(c["muted"])
        cv.drawString(1.8 * cm, 1.2 * cm, "AI Compliance Report")
        cv.drawRightString(A4[0] - 1.8 * cm, 1.2 * cm, f"Page {doc.page}")
        cv.restoreState()

    return cover, footer

def _score_table(w, cs, rs, s, c):
    def score_cell(lbl, val):
        hx = _score_col(val).hexval()[2:]
        return [
            Paragraph(f'<font color="#{hx}"><b>{val}/100</b></font>', s["score_value"]),
            Paragraph(lbl, s["score_label"]),
        ]
    tbl = Table([[
        Table([[p] for p in score_cell("Compliance Score", cs)], colWidths=[w/2-10]),
        Table([[p] for p in score_cell("Relevance Score",  rs)], colWidths=[w/2-10]),
    ]], colWidths=[w/2, w/2])
    tbl.setStyle(TableStyle([
        ("BOX",           (0,0),(-1,-1), 1,   c["border"]),
        ("INNERGRID",     (0,0),(-1,-1), .5,  c["border"]),
        ("BACKGROUND",    (0,0),(-1,-1),      c["light_bg"]),
        ("VALIGN",        (0,0),(-1,-1), "MIDDLE"),
        ("TOPPADDING",    (0,0),(-1,-1), 14),
        ("BOTTOMPADDING", (0,0),(-1,-1), 14),
    ]))
    return tbl

# =========================================================
# PDF 1 — AUDIT REPORT
# =========================================================

def generate_audit_pdf(company: str, doc_name: str,
                        analysis: str, identical: bool) -> bytes:
    buf  = BytesIO()
    c    = _bc()
    s    = _bs()
    w    = A4[0] - 3.6 * cm
    cover, footer = _make_cover_and_footer(c)

    pdoc = SimpleDocTemplate(buf, pagesize=A4,
                              leftMargin=1.8*cm, rightMargin=1.8*cm,
                              topMargin=2.2*cm,  bottomMargin=2.2*cm)

    story = [
        Spacer(1, 155),
        Paragraph("AI Compliance Audit Report", s["cover_title"]),
        Spacer(1, 4),
        Paragraph(f"Company Standard: {company}", s["cover_sub"]),
        Spacer(1, 2),
        Paragraph(
            f"Document Reviewed: {doc_name}    |    "
            f"Generated: {datetime.now().strftime('%d %B %Y, %H:%M')}",
            s["cover_meta"]
        ),
        Spacer(1, 40),
    ]

    cs, rs = (100, 100) if identical else _parse_scores(analysis)
    story += [KeepTogether(_score_table(w, cs, rs, s, c)), Spacer(1, 18)]

    if identical:
        story += [
            HRFlowable(width="100%", thickness=1, color=c["success"]),
            Spacer(1, 6),
            Paragraph("IDENTICAL DOCUMENT - 100% Compliant",
                ParagraphStyle("ib", parent=s["body"], textColor=c["success"],
                               fontName="Helvetica-Bold", fontSize=12, alignment=TA_CENTER)),
            Spacer(1, 4),
            Paragraph("The submitted document exactly matches the stored standard. No gaps detected.",
                ParagraphStyle("ibody", parent=s["body"], alignment=TA_CENTER, textColor=c["muted"])),
            HRFlowable(width="100%", thickness=1, color=c["success"]),
            Spacer(1, 14),
        ]

    story += [
        Paragraph("Audit Analysis", s["section_heading"]),
        HRFlowable(width="100%", thickness=1.5, color=c["accent"]),
        Spacer(1, 8),
    ]

    for sec_title, sec_body in _parse_sections(analysis):
        story.append(KeepTogether([Paragraph(sec_title, s["section_heading"])]))
        if "risk severity" in sec_title.lower():
            story.append(Paragraph(sec_body.strip(), _risk_style(sec_body, s)))
        else:
            for ln in sec_body.split("\n"):
                ln = ln.strip()
                if not ln:
                    story.append(Spacer(1, 3))
                    continue
                if ln.startswith(("-", "•")):
                    story.append(Paragraph(ln.lstrip("-• "), s["bullet"]))
                else:
                    story.append(Paragraph(ln, s["body"]))
        story.append(Spacer(1, 6))

    story += [
        Spacer(1, 20),
        HRFlowable(width="100%", thickness=.5, color=c["border"]),
        Spacer(1, 6),
        Paragraph("Generated by AI Compliance Reviewer. For internal review only. "
                  "Does not constitute legal advice.", s["footer_text"]),
    ]

    pdoc.build(story, onFirstPage=cover, onLaterPages=footer)
    return buf.getvalue()


# =========================================================
# PDF 2 — OPTIMIZED COMPLIANT DOCUMENT
# =========================================================

def generate_optimized_pdf(company: str, doc_name: str,
                            optimized_text: str, identical: bool) -> bytes:
    buf  = BytesIO()
    c    = _bc()
    s    = _bs()
    w    = A4[0] - 3.6 * cm

    def cover(cv, doc):
        cv.saveState()
        cv.setFillColor(colors.HexColor("#1A5C2E"))
        cv.rect(0, A4[1] - 220, A4[0], 220, fill=1, stroke=0)
        cv.setFillColor(colors.HexColor("#27AE60"))
        cv.rect(0, A4[1] - 226, A4[0], 8, fill=1, stroke=0)
        cv.restoreState()

    def footer(cv, doc):
        cv.saveState()
        cv.setFont("Helvetica", 8)
        cv.setFillColor(c["muted"])
        cv.drawString(1.8 * cm, 1.2 * cm, f"AI Policy Optimizer — {company}")
        cv.drawRightString(A4[0] - 1.8 * cm, 1.2 * cm, f"Page {doc.page}")
        cv.restoreState()

    pdoc = SimpleDocTemplate(buf, pagesize=A4,
                              leftMargin=1.8*cm, rightMargin=1.8*cm,
                              topMargin=2.2*cm,  bottomMargin=2.2*cm)

    story = [
        Spacer(1, 155),
        Paragraph("Optimized Compliant Document", s["cover_title"]),
        Spacer(1, 4),
        Paragraph(f"Company Standard: {company}", s["cover_sub"]),
        Spacer(1, 2),
        Paragraph(
            f"Source Document: {doc_name}    |    "
            f"Generated: {datetime.now().strftime('%d %B %Y, %H:%M')}",
            s["cover_meta"]
        ),
        Spacer(1, 40),
    ]

    if identical:
        story += [
            HRFlowable(width="100%", thickness=1, color=c["success"]),
            Spacer(1, 6),
            Paragraph("IDENTICAL DOCUMENT - Already 100% Compliant. No changes were required.",
                ParagraphStyle("ib", parent=s["body"], textColor=c["success"],
                               fontName="Helvetica-Bold", fontSize=11, alignment=TA_CENTER)),
            HRFlowable(width="100%", thickness=1, color=c["success"]),
            Spacer(1, 14),
        ]

    # Green info banner
    banner_tbl = Table(
        [[Paragraph(
            "This document has been fully rewritten by the AI Policy Optimizer to meet "
            "the company compliance standard. All identified gaps and missing clauses "
            "have been addressed. Review all changes before formal adoption.",
            ParagraphStyle("bntxt", parent=s["body"],
                           textColor=colors.HexColor("#1A5C2E"),
                           fontSize=9.5, leading=14)
        )]],
        colWidths=[w]
    )
    banner_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,-1), c["opt_green"]),
        ("BOX",           (0,0),(-1,-1), 1, c["opt_border"]),
        ("TOPPADDING",    (0,0),(-1,-1), 10),
        ("BOTTOMPADDING", (0,0),(-1,-1), 10),
        ("LEFTPADDING",   (0,0),(-1,-1), 12),
        ("RIGHTPADDING",  (0,0),(-1,-1), 12),
    ]))
    story += [banner_tbl, Spacer(1, 16)]

    for sec_title, sec_body in _parse_sections(optimized_text):
        is_changes = "changes made" in sec_title.lower() or "changes" == sec_title.lower().strip()
        heading_style = s["opt_heading"]
        story.append(KeepTogether([Paragraph(sec_title, heading_style)]))

        for ln in sec_body.split("\n"):
            ln = ln.strip()
            if not ln:
                story.append(Spacer(1, 3))
                continue
            if ln.startswith(("-", "•")):
                bstyle = s["opt_bullet"] if is_changes else s["bullet"]
                story.append(Paragraph(ln.lstrip("-• "), bstyle))
            else:
                story.append(Paragraph(ln, s["opt_body"]))
        story.append(Spacer(1, 6))

    story += [
        Spacer(1, 20),
        HRFlowable(width="100%", thickness=.5, color=c["border"]),
        Spacer(1, 6),
        Paragraph("Generated by AI Policy Optimizer. For internal review only. "
                  "Does not constitute legal advice.", s["footer_text"]),
    ]

    pdoc.build(story, onFirstPage=cover, onLaterPages=footer)
    return buf.getvalue()


# =========================================================
# COMBINED REPORT (both in one PDF, kept for reference)
# =========================================================

def generate_both_pdfs(company, doc_name, analysis, identical, optimized_text):
    """Returns (audit_bytes, optimized_bytes) as a tuple."""
    audit_bytes = generate_audit_pdf(company, doc_name, analysis, identical)
    opt_bytes   = generate_optimized_pdf(company, doc_name, optimized_text, identical)
    return audit_bytes, opt_bytes


# =========================================================
# CSS
# =========================================================

def inject_css():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');
    html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
    .stApp { background:#0D1117; color:#E6EDF3; }
    h1,h2,h3 { font-family:'IBM Plex Mono',monospace !important; }
    .main-title {
        font-family:'IBM Plex Mono',monospace; font-size:21px; font-weight:700;
        color:#58A6FF; letter-spacing:2px; text-transform:uppercase; padding:18px 0 4px 0;
    }
    
    .main-sub { font-size:13px; color:#8B949E; margin-bottom:24px; }
    .section-label {
        font-family:'IBM Plex Mono',monospace; font-size:11px; font-weight:600;
        color:#58A6FF; letter-spacing:2px; text-transform:uppercase;
        padding:4px 0 8px 0; border-bottom:1px solid #21262D; margin-bottom:12px;
    }
                
    .stTextInput>div>div>input {
        background:#161B22 !important; border:1px solid #30363D !important;
        color:#E6EDF3 !important; border-radius:8px !important;
        font-family:'DM Sans',sans-serif !important;
    }
    .stTextInput>div>div>input:focus {
        border-color:#58A6FF !important;
        box-shadow:0 0 0 3px rgba(88,166,255,.15) !important;
    }
    [data-testid="stFileUploader"] {
        background:#161B22 !important; border:1px dashed #30363D !important;
        border-radius:10px !important;
    }
    .stSelectbox>div>div {
        background:#161B22 !important; border:1px solid #30363D !important;
        border-radius:8px !important; color:#E6EDF3 !important;
    }
    .stButton>button {
        background:linear-gradient(135deg,#1F6FEB,#388BFD) !important;
        color:white !important; border:none !important; border-radius:8px !important;
        font-family:'IBM Plex Mono',monospace !important; font-size:11px !important;
        font-weight:700 !important; letter-spacing:1.5px !important;
        padding:10px 20px !important; transition:all .2s !important;
    }
    .stButton>button:hover {
        background:linear-gradient(135deg,#388BFD,#58A6FF) !important;
        transform:translateY(-1px) !important;
        box-shadow:0 4px 16px rgba(88,166,255,.3) !important;
    }
    /* audit download button — blue */
    div[data-testid="stDownloadButton"]:nth-of-type(1) button {
        background:linear-gradient(135deg,#1F6FEB,#388BFD) !important;
        color:white !important; border:none !important; border-radius:8px !important;
        font-family:'IBM Plex Mono',monospace !important; font-size:11px !important;
        font-weight:700 !important; letter-spacing:1px !important;
        width:100% !important; padding:12px !important;
    }
    /* optimized download button — green */
    div[data-testid="stDownloadButton"]:nth-of-type(2) button {
        background:linear-gradient(135deg,#238636,#2EA043) !important;
        color:white !important; border:none !important; border-radius:8px !important;
        font-family:'IBM Plex Mono',monospace !important; font-size:11px !important;
        font-weight:700 !important; letter-spacing:1px !important;
        width:100% !important; padding:12px !important;
    }
    .stDownloadButton>button {
        border-radius:8px !important; font-family:'IBM Plex Mono',monospace !important;
        font-size:11px !important; font-weight:700 !important; letter-spacing:1px !important;
        width:100% !important; padding:12px !important;
    }
    .stSuccess,.stError,.stInfo { border-radius:10px !important; }
    .stSpinner>div { border-top-color:#58A6FF !important; }
    hr { border-color:#21262D !important; }
    ::-webkit-scrollbar { width:6px; }
    ::-webkit-scrollbar-track { background:#0D1117; }
    ::-webkit-scrollbar-thumb { background:#30363D; border-radius:3px; }
                /* Analysis + Optimized text color */
.stText {
    color: #FFFFFF !important;
}

.stText textarea {
    color: #FFFFFF !important;
    background: #161B22 !important;
}

/* Tabs content text */
[data-testid="stMarkdownContainer"] p,
[data-testid="stMarkdownContainer"] span,
[data-testid="stMarkdownContainer"] div {
    color: #FFFFFF !important;
}

/* Streamlit info/success text */
.stInfo, .stSuccess {
    color: #FFFFFF !important;
}
    </style>
                
    """, unsafe_allow_html=True)

# =========================================================
# STREAMLIT APP
# =========================================================

st.set_page_config(page_title="AI Compliance Reviewer", layout="wide", page_icon="⚖️")
inject_css()

st.markdown('<div class="main-title">⚖️ AI Compliance Reviewer</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="main-sub">Multi-agent pipeline &middot; '
    'Extraction &rarr; Validation &rarr; Deduplication &rarr; RAG Retrieval &rarr; Audit &rarr; '
    '<b style="color:#2EA043">Policy Optimization</b> &rarr; Reports</div>',
    unsafe_allow_html=True
)

# ---- Session state init ----
for k, v in {
    "company_stored": False, "company_store_name": "", "company_file_hash": "",
    "company_error":  "",
    "analysis_done":  False, "analysis_text": "", "optimized_text": "",
    "analysis_is_identical": False, "analysis_company": "", "analysis_doc_name": "",
    "user_error": "", "audit_pdf": None, "opt_pdf": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v

# =========================================================
# TWO-COLUMN LAYOUT
# =========================================================

left_col, right_col = st.columns([1, 1], gap="large")

# ─────────────────────────────────────────────────────────
# LEFT — Store Company Standard
# ─────────────────────────────────────────────────────────
with left_col:
    st.markdown('<div class="section-label">01 — Store Company Standard</div>',
                unsafe_allow_html=True)

    company_name_input = st.text_input(
        "company_name", placeholder="e.g. Acme Corp", label_visibility="collapsed"
    )
    st.caption("Company name")

    company_file = st.file_uploader(
        "company_upload", type=["pdf","docx","txt"],
        key="company", label_visibility="collapsed"
    )
    st.caption("Upload company compliance standard (PDF / DOCX / TXT)")

    if company_file and company_name_input:
        if st.button("💾  STORE STANDARD", key="btn_store"):
            st.session_state.company_stored = False
            st.session_state.company_error  = ""
            pipe_ph = st.empty()
            pipe    = AgentPipeline(pipe_ph)

            r1 = pipe.run("extractor", agent_extract, company_file)
            if not r1.success:
                st.session_state.company_error = r1.error
                for aid in ["validator","dedup","retriever","auditor","optimizer","reporter"]:
                    pipe.fail(aid, "Skipped — extraction failed")
            else:
                company_text  = r1.data
                r2            = pipe.run("validator", agent_validate, company_text)
                valid, reason = r2.data if r2.success else (False, r2.error)

                if not valid:
                    st.session_state.company_error = reason
                    for aid in ["dedup","retriever","auditor","optimizer","reporter"]:
                        pipe.skip(aid, "Skipped — not a compliance document")
                else:
                    for aid in ["dedup","retriever","auditor","optimizer"]:
                        pipe.skip(aid, "N/A — storing standard")

                    r_store = pipe.run("reporter", agent_store_company,
                                       company_text, company_name_input)
                    if r_store.success:
                        already = r_store.data.get("already_existed", False)
                        st.session_state.company_stored     = True
                        st.session_state.company_store_name = company_name_input
                        st.session_state.company_file_hash  = r_store.data.get("hash", "")
                        pipe.override_msg("reporter",
                            "Already indexed — skipped re-index" if already
                            else "Indexed into vector store")
                    else:
                        st.session_state.company_error = r_store.error

    if st.session_state.company_error:
        st.error(f"Not a compliance document.\n\n{st.session_state.company_error}")
    elif st.session_state.company_stored:
        st.success(f"Standard stored for {st.session_state.company_store_name}")

# ─────────────────────────────────────────────────────────
# RIGHT — Analyse User Document
# ─────────────────────────────────────────────────────────
with right_col:
    st.markdown('<div class="section-label">02 — Analyse User Document</div>',
                unsafe_allow_html=True)

    stored_companies = []
    if os.path.exists("./compliance_index"):
        stored_companies = [
            n for n in os.listdir("./compliance_index")
            if os.path.isdir(os.path.join("./compliance_index", n)) and n != "__pycache__"
        ]

    selected_company = st.selectbox(
        "select_company", options=["— select —"] + stored_companies,
        label_visibility="collapsed"
    )
    st.caption("Select stored company standard")

    if selected_company != st.session_state.get("analysis_company", ""):
        st.session_state.analysis_done  = False
        st.session_state.user_error     = ""
        st.session_state.optimized_text = ""
        st.session_state.audit_pdf      = None
        st.session_state.opt_pdf        = None

    user_file = st.file_uploader(
        "user_upload", type=["pdf","docx","txt"],
        key="user", label_visibility="collapsed"
    )
    st.caption("Upload document to check (PDF / DOCX / TXT)")

    if user_file and selected_company and selected_company != "— select —":
        if st.button("🔍  RUN COMPLIANCE ANALYSIS", type="primary", key="btn_analyse"):
            st.session_state.analysis_done  = False
            st.session_state.user_error     = ""
            st.session_state.audit_pdf      = None
            st.session_state.opt_pdf        = None
            st.session_state.optimized_text = ""

            pipe_ph = st.empty()
            pipe    = AgentPipeline(pipe_ph)

            # Agent 1: Extract
            r1 = pipe.run("extractor", agent_extract, user_file)
            if not r1.success:
                st.session_state.user_error = r1.error
                for aid in ["validator","dedup","retriever","auditor","optimizer","reporter"]:
                    pipe.fail(aid, "Skipped")
            else:
                user_text = r1.data

                # Agent 2: Validate
                r2 = pipe.run("validator", agent_validate, user_text)
                valid, reason = r2.data if r2.success else (False, r2.error)

                if not valid:
                    st.session_state.user_error = reason
                    for aid in ["dedup","retriever","auditor","optimizer","reporter"]:
                        pipe.skip(aid, "Skipped — document rejected")
                else:
                    # Agent 3: Dedup
                    r3           = pipe.run("dedup", agent_dedup, user_text, selected_company)
                    is_identical = r3.data.get("is_identical", False) if r3.success else False

                    if is_identical:
                        pipe.override_msg("dedup", "Exact match - 100% compliant")
                        pipe.skip("retriever", "Skipped — identical document")
                        pipe.skip("auditor",   "Skipped — identical document")
                        pipe.skip("optimizer", "Skipped — already fully compliant")
                        analysis_text  = IDENTICAL_ANALYSIS
                        optimized_text = IDENTICAL_OPTIMIZED
                    else:
                        pipe.override_msg("dedup", "Documents differ — proceeding to full audit")

                        # Agent 4: Retrieve
                        r4 = pipe.run("retriever", agent_retrieve, selected_company)
                        if not r4.success:
                            st.session_state.user_error = r4.error
                            pipe.fail("auditor",   "Skipped — retrieval failed")
                            pipe.fail("optimizer", "Skipped — retrieval failed")
                            pipe.skip("reporter",  "Skipped")
                            st.rerun()

                        # Agent 5: Audit
                        r5 = pipe.run("auditor", agent_audit,
                                      r4.data, user_text, selected_company)
                        if not r5.success:
                            st.session_state.user_error = r5.error
                            pipe.fail("optimizer", "Skipped — audit failed")
                            pipe.skip("reporter",  "Skipped")
                            st.rerun()

                        analysis_text = r5.data

                        # Agent 6: Optimize
                        r6 = pipe.run("optimizer", agent_optimize,
                                      user_text, analysis_text, selected_company)
                        if r6.success:
                            optimized_text = r6.data
                            pipe.override_msg("optimizer",
                                              "Rewritten — fully compliant document generated")
                        else:
                            optimized_text = "Optimization could not be completed."
                            pipe.override_msg("optimizer", f"Failed: {r6.error[:80]}")

                    # Agent 7: Build both PDFs
                    def _build_pdfs():
                        a = generate_audit_pdf(
                            selected_company, user_file.name, analysis_text, is_identical)
                        o = generate_optimized_pdf(
                            selected_company, user_file.name, optimized_text, is_identical)
                        return a, o

                    r7 = pipe.run("reporter", _build_pdfs)

                    st.session_state.analysis_done         = True
                    st.session_state.analysis_text         = analysis_text
                    st.session_state.optimized_text        = optimized_text
                    st.session_state.analysis_is_identical = is_identical
                    st.session_state.analysis_company      = selected_company
                    st.session_state.analysis_doc_name     = user_file.name
                    if r7.success:
                        st.session_state.audit_pdf, st.session_state.opt_pdf = r7.data

    # ── Validation error ──────────────────────────────────
    if st.session_state.user_error:
        st.error(
            f"Not a compliance document.\n\n{st.session_state.user_error}\n\n"
            "Accepted: policies, handbooks, SOPs, codes of conduct, audit reports, etc."
        )

    # ── Results ───────────────────────────────────────────
    if st.session_state.analysis_done:
        analysis_text  = st.session_state.analysis_text
        optimized_text = st.session_state.optimized_text
        is_identical   = st.session_state.analysis_is_identical
        company_used   = st.session_state.analysis_company
        ts             = datetime.now().strftime("%Y%m%d_%H%M")

        if is_identical:
            st.success("Identical Document — 100% Compliant. No compliance gaps found.")
        else:
            st.success("Analysis + Optimization Complete")
            tab1, tab2 = st.tabs(["Audit Report", "Optimized Document"])
            with tab1:
                st.markdown(
    f"""
    <div style="color:white;background:#161B22;
                padding:15px;border-radius:10px;
                border:1px solid #30363D;
                white-space:pre-wrap;
                font-family:monospace;">
    {analysis_text}
    </div>
    """,
    unsafe_allow_html=True
)         # plain text — no markdown rendering
            with tab2:
                st.info(
                    "AI-rewritten version of your document, "
                    "fully corrected to meet the company compliance standard."
                )
                st.markdown(
    f"""
    <div style="color:white;background:#161B22;
                padding:15px;border-radius:10px;
                border:1px solid #30363D;
                white-space:pre-wrap;
                font-family:monospace;">
    {optimized_text}
    </div>
    """,
    unsafe_allow_html=True
)       # plain text — no markdown rendering

        # ── Two separate download buttons ─────────────────
        st.markdown("<br>", unsafe_allow_html=True)
        dl_col1, dl_col2 = st.columns(2, gap="small")

        with dl_col1:
            if st.session_state.audit_pdf:
                st.download_button(
                    label="⬇️  AUDIT REPORT PDF",
                    data=st.session_state.audit_pdf,
                    file_name=f"{company_used}_audit_{ts}.pdf",
                    mime="application/pdf",
                    key="dl_audit",
                )

        with dl_col2:
            if st.session_state.opt_pdf:
                st.download_button(
                    label="⬇️  OPTIMIZED DOCUMENT",
                    data=st.session_state.opt_pdf,
                    file_name=f"{company_used}_optimized_{ts}.pdf",
                    mime="application/pdf",
                    key="dl_opt",
                )