"""
Trade Forecast Project Skeleton
Replace excel_file with your workbook path.
"""
import pandas as pd
import matplotlib.pyplot as plt
from prophet import Prophet

excel_file=r"C:\path\Master_data_2years.xlsx"
FORECAST_MONTHS=6

xls=pd.ExcelFile(excel_file)

def forecast_sheet(sheet):
    df=pd.read_excel(excel_file,sheet_name=sheet).iloc[:,0:2]
    df.columns=["ds","y"]
    df["ds"]=pd.to_datetime(df["ds"])
    model=Prophet(yearly_seasonality=True,
                  weekly_seasonality=False,
                  daily_seasonality=False)
    model.fit(df)
    future=model.make_future_dataframe(periods=FORECAST_MONTHS,freq="MS")
    fc=model.predict(future)
    return df,fc

writer=pd.ExcelWriter("Forecast_Report.xlsx",engine="openpyxl")
for s in xls.sheet_names:
    hist,fc=forecast_sheet(s)
    fc[["ds","yhat","yhat_lower","yhat_upper"]].to_excel(writer,sheet_name=s[:31],index=False)
    plt.figure(figsize=(10,5))
    plt.plot(hist["ds"],hist["y"],label="Historical")
    fut=fc[fc["ds"]>hist["ds"].max()]
    plt.plot(fut["ds"],fut["yhat"],"--",label="Forecast")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{s}.png")
    plt.close()
writer.close()
print("Done")
