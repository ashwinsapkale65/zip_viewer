"""
app.py
------
Oracle PL/SQL Reverse Engineer — Streamlit entry point.

Run with:
    streamlit run app.py
"""

import logging
import time
from typing import Any

import streamlit as st

from core.classifier import classify_input, extract_code_block
from core.hasher import short_hash
from services import chromadb_service, ollama_client
from services.ollama_client import get_model_status, CHAT_MODEL, EMBED_MODEL
from ui.feedback_panel import render_feedback_form
from ui.admin_panel import render_admin_panel
from ui.result_panel import (
    render_dep_context_expander,
    render_download_button,
    render_result_badges,
)
from workflows.reverse_engineer import build_chat_messages, prepare_context, store_result

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Page configuration — MUST be first Streamlit call
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="PL/SQL Reverse Engineer",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get help": None,
        "Report a bug": None,
        "About": "Oracle PL/SQL Reverse Engineer powered by Ollama + ChromaDB",
    },
)

# ─────────────────────────────────────────────────────────────────────────────
# Custom CSS — premium dark theme
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    """
<style>
/* ── Google Fonts ────────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

/* ── Global reset & base ─────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; }

html, body, [data-testid="stAppViewContainer"], [class*="main"] {
    font-family: 'Inter', sans-serif !important;
}

/* ── Hide Streamlit chrome ───────────────────────────────────────────── */
#MainMenu { visibility: hidden; }
footer    { visibility: hidden; }
header    { visibility: hidden; }

/* ── Scrollbar ───────────────────────────────────────────────────────── */
::-webkit-scrollbar              { width: 6px; height: 6px; }
::-webkit-scrollbar-track        { background: #0A1428; }
::-webkit-scrollbar-thumb        { background: #2D3A5C; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover  { background: #4F5E8A; }

/* ── Sidebar ─────────────────────────────────────────────────────────── */
[data-testid="stSidebar"] {
    border-right: 1px solid rgba(99,102,241,0.25) !important;
}
[data-testid="stSidebar"] > div:first-child { padding: 1.2rem 1rem; }

/* ── Sidebar header card ─────────────────────────────────────────────── */
.sidebar-brand {
    background: linear-gradient(135deg, #1a1f3c 0%, #0e1530 100%);
    border: 1px solid rgba(99,102,241,0.4);
    border-radius: 14px;
    padding: 1.2rem 1rem;
    margin-bottom: 1.2rem;
    text-align: center;
    box-shadow: 0 4px 24px rgba(99,102,241,0.15);
}
.sidebar-brand .brand-icon { font-size: 2.4rem; display: block; margin-bottom: .3rem; }
.sidebar-brand .brand-title {
    font-size: 1.05rem; font-weight: 700; color: #A5B4FC; letter-spacing: .04em;
}
.sidebar-brand .brand-sub {
    font-size: .72rem; color: #64748B; margin-top: .15rem;
}

/* ── Status pill ─────────────────────────────────────────────────────── */
.status-pill {
    display: inline-flex; align-items: center; gap: .35rem;
    padding: .28rem .75rem; border-radius: 999px;
    font-size: .72rem; font-weight: 600; letter-spacing: .04em;
    margin-bottom: .6rem;
}
.status-pill.online  { background: rgba(16,185,129,.15); color: #34D399; border: 1px solid rgba(16,185,129,.35); }
.status-pill.offline { background: rgba(239,68,68,.15);  color: #FCA5A5; border: 1px solid rgba(239,68,68,.35);  }

/* ── Stat card ───────────────────────────────────────────────────────── */
.stat-card {
    background: rgba(15,23,60,0.7);
    border: 1px solid rgba(99,102,241,0.2);
    border-radius: 10px;
    padding: .8rem 1rem;
    margin-bottom: .6rem;
}
.stat-card .stat-val {
    font-size: 1.6rem; font-weight: 700;
    background: linear-gradient(90deg,#818CF8,#22D3EE);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.stat-card .stat-lbl { font-size: .72rem; color: #64748B; font-weight: 500; }

/* ── Recent object list ──────────────────────────────────────────────── */
.obj-row {
    display: flex; align-items: center; gap: .5rem;
    padding: .35rem .6rem; border-radius: 8px;
    background: rgba(99,102,241,0.07);
    border: 1px solid rgba(99,102,241,0.12);
    margin-bottom: .3rem; cursor: default;
    transition: background .2s;
}
.obj-row:hover { background: rgba(99,102,241,0.15); }
.obj-row .obj-type-badge {
    font-size: .62rem; font-weight: 700; padding: .1rem .4rem;
    border-radius: 4px; text-transform: uppercase; letter-spacing: .05em;
}
.obj-row .obj-name { font-size: .78rem; font-family: 'JetBrains Mono', monospace; }
.obj-row .obj-fb   { margin-left: auto; font-size: .75rem; }

/* ── Main chat area ──────────────────────────────────────────────────── */
[data-testid="block-container"] { padding: 1.5rem 2rem 6rem; max-width: 1100px; margin: 0 auto; }

/* ── Page title ──────────────────────────────────────────────────────── */
.page-title {
    background: linear-gradient(90deg, #6366F1, #22D3EE);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    font-size: 1.6rem; font-weight: 800; letter-spacing: -.01em;
    margin-bottom: .1rem;
}
.page-sub { font-size: .82rem; color: #475569; margin-bottom: 1.4rem; }

/* ── Chat messages ───────────────────────────────────────────────────── */
[data-testid="stChatMessage"] {
    border-radius: 14px !important;
    padding: 1rem 1.2rem !important;
    margin-bottom: .75rem !important;
    animation: fadeSlideIn .25s ease forwards;
}
[data-testid="stChatMessage"][data-role="user"] {
    border: 1px solid rgba(99,102,241,0.3) !important;
}
[data-testid="stChatMessage"][data-role="assistant"] {
    border: 1px solid rgba(34,211,238,0.18) !important;
}
@keyframes fadeSlideIn {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* ── Code blocks inside chat ─────────────────────────────────────────── */
[data-testid="stChatMessage"] pre, [data-testid="stChatMessage"] code {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: .8rem !important;
}
[data-testid="stChatMessage"] pre {
    border: 1px solid rgba(99,102,241,0.2) !important;
    border-radius: 8px !important;
    padding: .8rem 1rem !important;
}

/* ── Chat input ──────────────────────────────────────────────────────── */
[data-testid="stChatInput"] {
    border-top: 1px solid rgba(99,102,241,0.25) !important;
}
[data-testid="stChatInput"] textarea {
    border: 1px solid rgba(99,102,241,0.35) !important;
    border-radius: 10px !important;
    font-family: 'Inter', sans-serif !important;
    font-size: .88rem !important;
}
[data-testid="stChatInput"] textarea:focus {
    border-color: rgba(99,102,241,0.7) !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.12) !important;
}

/* ── Dividers / separators ───────────────────────────────────────────── */
hr { border-color: rgba(99,102,241,0.15) !important; margin: 1rem 0 !important; }

/* ── Badges (result_panel) ───────────────────────────────────────────── */
.badge {
    display: inline-flex; align-items: center;
    padding: .22rem .6rem; border-radius: 999px;
    font-size: .68rem; font-weight: 600; letter-spacing: .04em;
    margin-right: .3rem; margin-bottom: .4rem;
}
.badge-cache { background: rgba(16,185,129,.15); color: #34D399; border: 1px solid rgba(16,185,129,.35); }
.badge-new   { background: rgba(99,102,241,.18); color: #A5B4FC; border: 1px solid rgba(99,102,241,.4);  }
.badge-dep   { background: rgba(245,158,11,.12); color: #FCD34D; border: 1px solid rgba(245,158,11,.35); }
.badge-proc  { background: rgba(34,211,238,.12); color: #67E8F9; border: 1px solid rgba(34,211,238,.35); }
.badge-func  { background: rgba(139,92,246,.15); color: #C4B5FD; border: 1px solid rgba(139,92,246,.4);  }
.badge-pkg   { background: rgba(249,115,22,.12); color: #FDBA74; border: 1px solid rgba(249,115,22,.35); }
.badge-trig  { background: rgba(236,72,153,.12); color: #F9A8D4; border: 1px solid rgba(236,72,153,.35); }
.badge-type  { background: rgba(20,184,166,.12); color: #5EEAD4; border: 1px solid rgba(20,184,166,.35); }
.badge-name  { background: rgba(51,65,85,.5);    color: #94A3B8; border: 1px solid rgba(100,116,139,.4); }
.badge-hash  { background: rgba(15,23,42,.8);    color: #475569; border: 1px solid rgba(51,65,85,.5);    font-family: 'JetBrains Mono', monospace; }

/* ── Feedback bar ────────────────────────────────────────────────────── */
.feedback-bar {
    margin-top: .8rem;
    padding: .55rem .8rem;
    border-top: 1px solid rgba(99,102,241,0.15);
    border-radius: 0 0 10px 10px;
    display: flex; flex-wrap: wrap; align-items: center; gap: .4rem;
}
.feedback-prompt { font-size: .76rem; color: #64748B; }
.feedback-done   { font-size: .76rem; color: #34D399;  }

/* ── Streamlit buttons ───────────────────────────────────────────────── */
.stButton > button {
    border-radius: 8px !important;
    font-family: 'Inter', sans-serif !important;
    font-weight: 500 !important;
    transition: all .18s ease !important;
}
.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #6366F1, #4F46E5) !important;
    border: none !important;
    color: #fff !important;
}
.stButton > button[kind="primary"]:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 6px 20px rgba(99,102,241,0.35) !important;
}

/* ── Expander ────────────────────────────────────────────────────────── */
details summary {
    color: #818CF8 !important;
    font-size: .82rem !important;
    font-weight: 600 !important;
}

/* ── Info / warning / success boxes ─────────────────────────────────── */
[data-testid="stAlert"] {
    border-radius: 10px !important;
    font-size: .82rem !important;
}

/* ── Download button ─────────────────────────────────────────────────── */
.stDownloadButton > button {
    background: transparent !important;
    border: 1px solid rgba(99,102,241,0.35) !important;
    color: #818CF8 !important;
    font-size: .78rem !important;
    border-radius: 8px !important;
    padding: .3rem .8rem !important;
}
.stDownloadButton > button:hover {
    background: rgba(99,102,241,0.12) !important;
    border-color: rgba(99,102,241,0.6) !important;
}

/* ── Spinner override ────────────────────────────────────────────────── */
[data-testid="stSpinner"] { color: #818CF8 !important; }

/* ── Text area ───────────────────────────────────────────────────────── */
textarea {
    border: 1px solid rgba(99,102,241,0.25) !important;
    border-radius: 8px !important;
    font-size: .83rem !important;
}

/* ── Markdown headings inside chat ──────────────────────────────────── */
[data-testid="stChatMessage"] h3 {
    color: #818CF8 !important;
    font-size: .95rem !important;
    font-weight: 600 !important;
    margin-top: 1.1rem !important;
    padding-bottom: .25rem !important;
    border-bottom: 1px solid rgba(99,102,241,0.2) !important;
}
[data-testid="stChatMessage"] h2 {
    color: #A5B4FC !important; font-size: 1.05rem !important;
}
[data-testid="stChatMessage"] li     { margin-bottom: .15rem !important; }

/* ── Step list numbers ───────────────────────────────────────────────── */
[data-testid="stChatMessage"] ol li::marker {
    color: #6366F1 !important; font-weight: 700 !important;
}

/* ── Progress / status area ──────────────────────────────────────────── */
.re-status {
    font-size: .8rem; color: #64748B; padding: .4rem 0;
    font-style: italic; letter-spacing: .02em;
}
</style>
""",
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────────────────
# Session state initialisation
# ─────────────────────────────────────────────────────────────────────────────
_DEFAULTS: dict[str, Any] = {
    "messages":         [],      # list of message dicts
    "last_code_hash":   None,    # hash of most recently processed PL/SQL
    "ollama_ok":        None,    # cached Ollama health check
    "stats_cache":      None,    # cached ChromaDB stats
    "stats_cache_ts":   0.0,     # epoch timestamp of last stats refresh
}
for _k, _v in _DEFAULTS.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v


# ─────────────────────────────────────────────────────────────────────────────
# Helper: cached ChromaDB stats (refresh every 60 s)
# ─────────────────────────────────────────────────────────────────────────────
def _get_stats() -> dict:
    now = time.time()
    if (
        st.session_state.stats_cache is None
        or now - st.session_state.stats_cache_ts > 60
    ):
        try:
            st.session_state.stats_cache    = chromadb_service.get_collection_stats()
            st.session_state.stats_cache_ts = now
        except Exception:
            st.session_state.stats_cache = {
                "total": 0, "type_counts": {}, "feedback_pos": 0, "feedback_neg": 0
            }
    return st.session_state.stats_cache


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:

    # ── Brand header ─────────────────────────────────────────────────────────
    st.markdown(
        """
        <div class="sidebar-brand">
          <span class="brand-icon">🔬</span>
          <div class="brand-title">PL/SQL Reverse Engineer</div>
          <div class="brand-sub">Ollama · ChromaDB · deepseek-r1:14b</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Ollama status ──────────────────────────────────────────────────────
    if st.session_state.ollama_ok is None:
        st.session_state.ollama_ok = ollama_client.is_ollama_available()

    if st.session_state.ollama_ok:
        st.markdown(
            '<div class="status-pill online">● Ollama Connected</div>',
            unsafe_allow_html=True,
        )
        # Per-model pull status
        try:
            mstatus = get_model_status()
            chat_ok  = mstatus.get("chat",  False)
            embed_ok = mstatus.get("embed", False)
            for label, model_name, ok in [
                ("Chat model",  CHAT_MODEL,  chat_ok),
                ("Embed model", EMBED_MODEL, embed_ok),
            ]:
                if ok:
                    st.markdown(
                        f'<div style="font-size:.74rem;color:#34D399;padding:.1rem 0;">'
                        f'✓ {label}: <code style="color:#34D399;">{model_name}</code></div>',
                        unsafe_allow_html=True,
                    )
                else:
                    st.markdown(
                        f'<div style="font-size:.74rem;color:#FCA5A5;padding:.1rem 0;">'
                        f'✗ {label} not pulled</div>',
                        unsafe_allow_html=True,
                    )
                    st.code(f"ollama pull {model_name}", language="bash")
        except Exception:
            pass
    else:
        st.markdown(
            '<div class="status-pill offline">● Ollama Offline</div>',
            unsafe_allow_html=True,
        )
        st.warning(
            "Ollama is not reachable at `http://localhost:11434`.\n\n"
            "Start Ollama and ensure **deepseek-r1:14b** and **mxbai-embed-large** are pulled.",
            icon="⚠️",
        )

    st.markdown("---")

    # ── ChromaDB stats ────────────────────────────────────────────────────
    stats = _get_stats()
    st.markdown("**📊 Knowledge Base**")

    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown(
            f'<div class="stat-card">'
            f'  <div class="stat-val">{stats["total"]}</div>'
            f'  <div class="stat-lbl">Objects Stored</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    with col_b:
        pos = stats.get("feedback_pos", 0)
        neg = stats.get("feedback_neg", 0)
        st.markdown(
            f'<div class="stat-card">'
            f'  <div class="stat-val">👍{pos} 👎{neg}</div>'
            f'  <div class="stat-lbl">Feedback</div>'
            f'</div>',
            unsafe_allow_html=True,
        )

    # Type breakdown
    if stats.get("type_counts"):
        type_colors = {
            "PROCEDURE":    "#67E8F9",
            "FUNCTION":     "#C4B5FD",
            "PACKAGE BODY": "#FDBA74",
            "PACKAGE":      "#FDBA74",
            "TRIGGER":      "#F9A8D4",
        }
        for otype, count in sorted(stats["type_counts"].items()):
            color = type_colors.get(otype, "#94A3B8")
            st.markdown(
                f'<div style="display:flex;justify-content:space-between;'
                f'font-size:.75rem;padding:.1rem 0;color:#94A3B8;">'
                f'<span style="color:{color};">⬤ {otype}</span>'
                f'<span style="font-weight:600;">{count}</span></div>',
                unsafe_allow_html=True,
            )

    st.markdown("---")

    # ── Recent objects ────────────────────────────────────────────────────
    st.markdown("**🕐 Recent Objects**")
    try:
        recent = chromadb_service.get_recent_objects(limit=6)
        if recent:
            type_badge_colors = {
                "PROCEDURE":    "#67E8F9", "FUNCTION": "#C4B5FD",
                "PACKAGE BODY": "#FDBA74", "PACKAGE":  "#FDBA74",
                "TRIGGER":      "#F9A8D4",
            }
            for obj in recent:
                c = type_badge_colors.get(obj["object_type"], "#94A3B8")
                fb_icon = (
                    "👍" if obj["feedback_score"] == 1
                    else "👎" if obj["feedback_score"] == -1
                    else ""
                )
                short_type = obj["object_type"].replace("PACKAGE BODY", "PKG.BODY")
                st.markdown(
                    f'<div class="obj-row">'
                    f'  <span class="obj-type-badge" style="color:{c};border:1px solid {c}40;">'
                    f'    {short_type}</span>'
                    f'  <span class="obj-name">{obj["object_name"]}</span>'
                    f'  <span class="obj-fb">{fb_icon}</span>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
        else:
            st.markdown(
                '<span style="font-size:.75rem;color:#475569;">'
                "No objects stored yet.</span>",
                unsafe_allow_html=True,
            )
    except Exception:
        st.markdown(
            '<span style="font-size:.75rem;color:#475569;">Knowledge base unavailable.</span>',
            unsafe_allow_html=True,
        )

    st.markdown("---")

    # ── Controls ──────────────────────────────────────────────────────────
    st.markdown("**⚙️ Controls**")
    if st.button("🔄 Refresh Ollama Status", use_container_width=True):
        st.session_state.ollama_ok   = ollama_client.is_ollama_available()
        st.session_state.stats_cache = None   # force stats refresh
        st.rerun()

    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.messages       = []
        st.session_state.last_code_hash = None
        st.rerun()

    st.markdown("---")
    
    render_admin_panel()
    st.markdown(
        '<div style="font-size:.68rem;color:#334155;text-align:center;">'
        "Model: deepseek-r1:14b<br>Embed: mxbai-embed-large<br>"
        "Vector DB: ChromaDB (local)<br><br>"
        "Paste PL/SQL code in the chat to start reverse engineering."
        "</div>",
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Main area — page header
# ─────────────────────────────────────────────────────────────────────────────
st.markdown(
    '<div class="page-title">🔬 Oracle PL/SQL Reverse Engineer</div>'
    '<div class="page-sub">'
    "Paste any PL/SQL procedure, function, package, or trigger to generate a complete "
    "step-by-step reverse engineering document. Normal questions also work — just type."
    "</div>",
    unsafe_allow_html=True,
)

# ─────────────────────────────────────────────────────────────────────────────
# Render chat history
# ─────────────────────────────────────────────────────────────────────────────
for i, msg in enumerate(st.session_state.messages):
    role       = msg["role"]
    content    = msg["content"]
    msg_type   = msg.get("type", "chat")
    code_hash  = msg.get("code_hash")
    from_cache = msg.get("from_cache", False)
    dep_count  = msg.get("dep_count", 0)

    with st.chat_message(role):
        if role == "assistant" and msg_type == "plsql" and code_hash:
            # ── Render PL/SQL result ──────────────────────────────────────
            render_result_badges(
                from_cache  = from_cache,
                dep_count   = dep_count,
                object_type = msg.get("object_type", ""),
                object_name = msg.get("object_name", ""),
                code_hash   = code_hash,
            )
            st.markdown(content)

            # Export button
            col_dl, col_spacer = st.columns([2, 8])
            with col_dl:
                render_download_button(
                    content,
                    msg.get("object_name", "plsql_result"),
                    key_suffix=f"{code_hash}_{i}",
                )

            # Dependency expander (stored in message)
            if msg.get("dep_context"):
                render_dep_context_expander(msg["dep_context"])

            st.markdown("---")
            render_feedback_form(code_hash, key_suffix=f"{code_hash}_{i}")
        else:
            st.markdown(content)


# ─────────────────────────────────────────────────────────────────────────────
# Chat input
# ─────────────────────────────────────────────────────────────────────────────
if user_input := st.chat_input(
    "Chat or paste PL/SQL code here… (Shift+Enter for new line)",
    key="main_chat_input",
):
    # ── Append and render user message ────────────────────────────────────
    st.session_state.messages.append(
        {"role": "user", "content": user_input, "type": "chat"}
    )
    with st.chat_message("user"):
        st.markdown(user_input)

    # ── Classify input ────────────────────────────────────────────────────
    input_type = classify_input(user_input)

    # ─────────────────────────────────────────────────────────────────────
    # Branch A: Normal chat
    # ─────────────────────────────────────────────────────────────────────
    if input_type == "chat":
        with st.chat_message("assistant"):
            messages = build_chat_messages(
                user_input,
                st.session_state.messages[:-1],  # exclude the just-appended user msg
            )
            if not st.session_state.ollama_ok:
                response = (
                    "⚠️ Ollama appears to be offline. "
                    "Please start Ollama and ensure **deepseek-r1:14b** is loaded."
                )
                st.markdown(response)
            else:
                try:
                    response = st.write_stream(
                        ollama_client.stream_chat_completion(messages)
                    )
                except RuntimeError as exc:
                    response = f"❌ **Error communicating with Ollama:**\n\n```\n{exc}\n```"
                    st.markdown(response)

        st.session_state.messages.append(
            {"role": "assistant", "content": response, "type": "chat"}
        )

    # ─────────────────────────────────────────────────────────────────────
    # Branch B: PL/SQL or mixed — reverse engineering workflow
    # ─────────────────────────────────────────────────────────────────────
    else:
        # Extract code portion if mixed
        if input_type == "mixed":
            chat_prefix, plsql_code = extract_code_block(user_input)
        else:
            chat_prefix, plsql_code = "", user_input

        if not plsql_code.strip():
            plsql_code = user_input   # fallback — treat everything as code

        with st.chat_message("assistant"):

            # ── Check Ollama availability ─────────────────────────────────
            if not st.session_state.ollama_ok:
                st.session_state.ollama_ok = ollama_client.is_ollama_available()

            if not st.session_state.ollama_ok:
                err = (
                    "⚠️ Ollama is offline. "
                    "Please start Ollama with **deepseek-r1:14b** and **mxbai-embed-large** loaded."
                )
                st.warning(err)
                st.session_state.messages.append(
                    {"role": "assistant", "content": err, "type": "chat"}
                )
                st.stop()

            # ── Phase 1: prepare context ──────────────────────────────────
            status_placeholder = st.empty()
            status_placeholder.markdown(
                '<div class="re-status">⚙️ Parsing PL/SQL structure…</div>',
                unsafe_allow_html=True,
            )

            try:
                ctx = prepare_context(plsql_code)
            except Exception as exc:
                err = f"❌ **Failed to prepare context:**\n\n```\n{exc}\n```"
                status_placeholder.empty()
                st.markdown(err)
                st.session_state.messages.append(
                    {"role": "assistant", "content": err, "type": "chat"}
                )
                st.stop()

            meta       = ctx["metadata"]
            code_hash  = ctx["code_hash"]
            from_cache = ctx["from_cache"]
            dep_ctx    = ctx["dep_context"]

            # ── Render result badges ──────────────────────────────────────
            status_placeholder.empty()
            render_result_badges(
                from_cache  = from_cache,
                dep_count   = len(dep_ctx),
                object_type = meta.get("object_type", ""),
                object_name = meta.get("object_name", ""),
                code_hash   = code_hash,
            )

            # ── Cache hit: display immediately ────────────────────────────
            if from_cache:
                explanation = ctx["explanation"]
                st.markdown(explanation)

            # ── Cache miss: stream LLM response ──────────────────────────
            else:
                if dep_ctx:
                    status_placeholder = st.empty()
                    status_placeholder.markdown(
                        f'<div class="re-status">'
                        f"🔗 Using {len(dep_ctx)} dependency context(s) from knowledge base…"
                        f"</div>",
                        unsafe_allow_html=True,
                    )
                    time.sleep(0.6)
                    status_placeholder.empty()

                try:
                    explanation = st.write_stream(
                        ollama_client.stream_chat_completion(ctx["messages"])
                    )
                except RuntimeError as exc:
                    err = f"❌ **LLM streaming error:**\n\n```\n{exc}\n```"
                    st.markdown(err)
                    st.session_state.messages.append(
                        {"role": "assistant", "content": err, "type": "chat"}
                    )
                    st.stop()

                # ── Phase 2: store result ─────────────────────────────────
                with st.spinner("💾 Saving to knowledge base…"):
                    try:
                        store_result(
                            raw_code     = plsql_code,
                            code_hash    = code_hash,
                            cleaned_code = ctx["cleaned_code"],
                            explanation  = explanation,
                            metadata     = meta,
                            dep_context  = dep_ctx,
                        )
                        # Refresh stats cache
                        st.session_state.stats_cache = None
                    except Exception as exc:
                        st.warning(f"⚠️ Could not save to knowledge base: {exc}")

            # ── Export button ─────────────────────────────────────────────
            col_dl, _ = st.columns([2, 8])
            with col_dl:
                render_download_button(
                    explanation,
                    meta.get("object_name", "plsql_result"),
                    key_suffix=f"{code_hash}_new",
                )

            # ── Dependency context expander ───────────────────────────────
            if dep_ctx:
                render_dep_context_expander(dep_ctx)

            # ── Feedback form ─────────────────────────────────────────────
            st.markdown("---")
            render_feedback_form(code_hash, key_suffix=f"{code_hash}_new")

        # ── Save to session state ─────────────────────────────────────────
        st.session_state.messages.append({
            "role":        "assistant",
            "content":     explanation,
            "type":        "plsql",
            "code_hash":   code_hash,
            "from_cache":  from_cache,
            "dep_count":   len(dep_ctx),
            "dep_context": dep_ctx,
            "object_type": meta.get("object_type", ""),
            "object_name": meta.get("object_name", ""),
        })
        st.session_state.last_code_hash = code_hash
