"""
services/ollama_client.py
--------------------------
Thin HTTP client for the locally hosted Ollama server.

Supports:
  - get_embedding()          – mxbai-embed-large embeddings
  - chat_completion()        – single-shot chat (returns full string)
  - stream_chat_completion() – streaming chat (yields text chunks)
"""

import json
import logging
import os
from typing import Generator

import requests
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────
OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
CHAT_MODEL:      str = os.getenv("OLLAMA_CHAT_MODEL",  "deepseek-r1:14b")
EMBED_MODEL:     str = os.getenv("OLLAMA_EMBED_MODEL", "mxbai-embed-large")

_EMBED_TIMEOUT = 120   # seconds
_CHAT_TIMEOUT  = 600   # seconds – large models can be slow


# ─────────────────────────────────────────────────────────────────────────────
# Internal: extract human-readable error from Ollama HTTP error response
# ─────────────────────────────────────────────────────────────────────────────

def _parse_ollama_error(response: requests.Response, default_model: str) -> str:
    """
    Parse Ollama's JSON error body {"error": "..."} for a helpful message.
    Falls back to the HTTP status text.
    """
    try:
        body      = response.json()
        ollama_msg = body.get("error", "").strip()
    except Exception:
        ollama_msg = response.text.strip()

    if not ollama_msg:
        ollama_msg = f"HTTP {response.status_code}"

    hint = ""
    lower = ollama_msg.lower()
    if "not found" in lower or "pull" in lower or "unknown model" in lower:
        hint = (
            f"\n\n💡 Run in your terminal:  ollama pull {default_model}"
        )
    return f"{ollama_msg}{hint}"


# ─────────────────────────────────────────────────────────────────────────────
# Embedding
# ─────────────────────────────────────────────────────────────────────────────

def get_embedding(text: str) -> list[float]:
    """
    Generate a text embedding using mxbai-embed-large via Ollama.

    Tries the newer /api/embed endpoint (Ollama ≥ 0.3) first,
    then falls back to the legacy /api/embeddings endpoint.
    """
    if not text or not text.strip():
        raise ValueError("Cannot embed empty text.")

    # ── New endpoint (Ollama ≥ 0.3) ──────────────────────────────────────────
    try:
        resp = requests.post(
            f"{OLLAMA_BASE_URL}/api/embed",
            json={"model": EMBED_MODEL, "input": text.strip()},
            timeout=_EMBED_TIMEOUT,
        )
        if resp.status_code == 200:
            data = resp.json()
            embeddings = data.get("embeddings") or data.get("embedding")
            if embeddings:
                return embeddings[0] if isinstance(embeddings[0], list) else embeddings
    except requests.RequestException:
        pass  # fall through to legacy endpoint

    # ── Legacy endpoint (Ollama < 0.3) ────────────────────────────────────────
    try:
        resp = requests.post(
            f"{OLLAMA_BASE_URL}/api/embeddings",
            json={"model": EMBED_MODEL, "prompt": text.strip()},
            timeout=_EMBED_TIMEOUT,
        )
        if not resp.ok:
            msg = _parse_ollama_error(resp, EMBED_MODEL)
            raise RuntimeError(f"Ollama embed error (HTTP {resp.status_code}): {msg}")
        return resp.json()["embedding"]
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(
            f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. Is Ollama running?"
        ) from exc
    except RuntimeError:
        raise
    except requests.RequestException as exc:
        raise RuntimeError(f"Ollama embedding failed: {exc}") from exc


# ─────────────────────────────────────────────────────────────────────────────
# Single-shot chat
# ─────────────────────────────────────────────────────────────────────────────

def chat_completion(messages: list[dict[str, str]]) -> str:
    """
    Send chat messages to Ollama and return the full response string.

    The `options` key (temperature etc.) is intentionally omitted —
    some Ollama versions return HTTP 500 when unrecognised option keys are included.
    """
    try:
        resp = requests.post(
            f"{OLLAMA_BASE_URL}/api/chat",
            json={
                "model":    CHAT_MODEL,
                "messages": messages,
                "stream":   False,
            },
            timeout=_CHAT_TIMEOUT,
        )
        if not resp.ok:
            msg = _parse_ollama_error(resp, CHAT_MODEL)
            raise RuntimeError(f"Ollama chat error (HTTP {resp.status_code}): {msg}")
        return resp.json()["message"]["content"]
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(
            f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. Is Ollama running?"
        ) from exc
    except RuntimeError:
        raise
    except requests.RequestException as exc:
        raise RuntimeError(f"Ollama chat failed: {exc}") from exc


# ─────────────────────────────────────────────────────────────────────────────
# Streaming chat
# ─────────────────────────────────────────────────────────────────────────────

def stream_chat_completion(messages: list[dict[str, str]]) -> Generator[str, None, None]:
    """
    Stream a chat response from Ollama, yielding text chunks as they arrive.

    The `options` key is intentionally omitted to avoid HTTP 500 on some builds.
    On any non-2xx response the actual Ollama error message is raised as a
    RuntimeError (including a helpful `ollama pull` hint if the model is missing).
    """
    try:
        with requests.post(
            f"{OLLAMA_BASE_URL}/api/chat",
            json={
                "model":    CHAT_MODEL,
                "messages": messages,
                "stream":   True,
            },
            stream=True,
            timeout=_CHAT_TIMEOUT,
        ) as resp:
            # ── Non-2xx: read error body then raise ─────────────────────────
            if not resp.ok:
                msg = _parse_ollama_error(resp, CHAT_MODEL)
                raise RuntimeError(f"Ollama chat error (HTTP {resp.status_code}): {msg}")

            # ── Stream OK: yield chunks ──────────────────────────────────────
            for raw_line in resp.iter_lines():
                if not raw_line:
                    continue
                try:
                    chunk = json.loads(raw_line)
                except json.JSONDecodeError:
                    logger.warning("Non-JSON line from Ollama: %s", raw_line)
                    continue
                content = chunk.get("message", {}).get("content", "")
                if content:
                    yield content
                if chunk.get("done", False):
                    break

    except RuntimeError:
        raise   # re-raise our own errors unchanged
    except requests.exceptions.ConnectionError as exc:
        raise RuntimeError(
            f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. Is Ollama running?"
        ) from exc
    except requests.RequestException as exc:
        raise RuntimeError(f"Ollama streaming failed: {exc}") from exc


# ─────────────────────────────────────────────────────────────────────────────
# Health + model availability checks
# ─────────────────────────────────────────────────────────────────────────────

def is_ollama_available() -> bool:
    """Return True if the Ollama server responds to a health-check ping."""
    try:
        r = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        return r.status_code == 200
    except requests.RequestException:
        return False


def get_available_models() -> list[str]:
    """Return list of model names currently pulled in Ollama."""
    try:
        r = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        return []


def get_model_status() -> dict[str, bool]:
    """
    Return pull-status for both required models.

    Returns:
        {"chat": bool, "embed": bool}
        True  = model is available and ready.
        False = model is not pulled yet.
    """
    available = get_available_models()

    def _check(name: str) -> bool:
        base = name.split(":")[0].lower()
        for m in available:
            if m.lower() == name.lower() or m.lower().startswith(base + ":"):
                return True
        return False

    return {"chat": _check(CHAT_MODEL), "embed": _check(EMBED_MODEL)}
