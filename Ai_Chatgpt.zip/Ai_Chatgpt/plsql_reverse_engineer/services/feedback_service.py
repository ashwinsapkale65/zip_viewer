"""
services/feedback_service.py
-----------------------------
High-level feedback operations that bridge the Streamlit UI
and ChromaDB storage.

Feedback is stored directly on the ChromaDB document via
chromadb_service.update_feedback().
"""

import logging

from services import chromadb_service

logger = logging.getLogger(__name__)


def submit_feedback(
    code_hash:  str,
    thumbs_up:  bool,
    correction: str = "",
) -> dict[str, str]:
    """
    Record user feedback for a reverse-engineered document.

    Args:
        code_hash:  SHA-256 hash used as the ChromaDB document ID.
        thumbs_up:  True = positive, False = negative.
        correction: Optional free-text correction provided by the user.

    Returns:
        A dict with "status" ("ok" | "error") and a "message" string.
    """
    score = 1 if thumbs_up else -1
    ok    = chromadb_service.update_feedback(code_hash, score, correction)

    if ok:
        sentiment = "positive" if thumbs_up else "negative"
        msg = (
            f"Thank you for your {sentiment} feedback!"
            + (
                " Your correction has been saved and will be included "
                "in future context for this object."
                if correction.strip()
                else ""
            )
        )
        logger.info(
            "Feedback recorded: hash=%s…, score=%d", code_hash[:8], score
        )
        return {"status": "ok", "message": msg}

    logger.warning("Feedback failed: no document found for hash %s.", code_hash)
    return {
        "status":  "error",
        "message": "Could not save feedback — document not found in knowledge base.",
    }


def get_feedback_summary(code_hash: str) -> dict:
    """
    Retrieve the current feedback score for a document.

    Returns:
        {"score": int, "label": str}
        score:  0 = none, 1 = positive, -1 = negative
        label:  "No feedback" | "👍 Positive" | "👎 Negative"
    """
    doc = chromadb_service.search_by_hash(code_hash)
    if not doc:
        return {"score": 0, "label": "No feedback"}

    score = doc["metadata"].get("feedback_score", 0)
    label_map = {1: "👍 Positive", -1: "👎 Negative", 0: "No feedback"}
    return {"score": score, "label": label_map.get(score, "No feedback")}
