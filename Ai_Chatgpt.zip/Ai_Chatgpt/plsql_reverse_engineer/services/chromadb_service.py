"""
services/chromadb_service.py
-----------------------------
All ChromaDB interactions for the PL/SQL knowledge base.

Collection schema (per document):
  id          → SHA-256 hash of cleaned code (primary key)
  document    → Full explanation markdown text
  embedding   → mxbai-embed-large vector
  metadata    → {
      object_name, object_type, package_name,
      code_hash, raw_code, cleaned_code,
      functional_summary, technical_summary,
      dependencies, tables_used,
      created_at, updated_at, feedback_score
  }
"""

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Optional

import chromadb
from chromadb.config import Settings
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────
_DB_PATH        = os.getenv("CHROMADB_PATH", "./data/chromadb")
_COLLECTION     = os.getenv("CHROMADB_COLLECTION", "plsql_knowledge")
_MAX_DEP_RESULTS = 3   # max hits per dependency search
_DEP_DISTANCE    = 0.45  # cosine-distance threshold (lower = more similar)

# ── Singleton client + collection ─────────────────────────────────────────────
_client:     Optional[chromadb.PersistentClient] = None
_collection: Optional[Any]                       = None


def _get_collection() -> Any:
    """Lazily initialise the ChromaDB persistent client and collection."""
    global _client, _collection
    if _collection is not None:
        return _collection

    os.makedirs(_DB_PATH, exist_ok=True)
    _client = chromadb.PersistentClient(
        path=_DB_PATH,
        settings=Settings(anonymized_telemetry=False),
    )
    _collection = _client.get_or_create_collection(
        name=_COLLECTION,
        metadata={"hnsw:space": "cosine"},
    )
    logger.info("ChromaDB collection '%s' ready at '%s'.", _COLLECTION, _DB_PATH)
    return _collection


# ─────────────────────────────────────────────────────────────────────────────
# Read operations
# ─────────────────────────────────────────────────────────────────────────────

def search_by_hash(code_hash: str) -> Optional[dict[str, Any]]:
    """
    Look up a document by its exact SHA-256 code hash.

    Returns the stored document dict, or None if not found.
    This is the primary cache-hit check — zero LLM/embed calls if matched.
    """
    col = _get_collection()
    try:
        result = col.get(
            ids=[code_hash],
            include=["documents", "metadatas", "embeddings"],
        )
        if result.get("ids") and len(result["ids"]) > 0:
            # Handle Numpy array format if returned by ChromaDB
            emb = None
            if result.get("embeddings") is not None and len(result["embeddings"]) > 0:
                emb = result["embeddings"][0]
                if hasattr(emb, "tolist"):
                    emb = emb.tolist()

            return {
                "id":          result["ids"][0],
                "explanation": result["documents"][0],
                "metadata":    result["metadatas"][0],
                "embedding":   emb,
            }
    except Exception as exc:
        logger.error("search_by_hash error: %s", exc)
    return None


def search_by_name(
    object_name: str,
    package_name: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """
    Search the collection by object name (and optional package name).
    Uses ChromaDB metadata filters for exact matching.
    """
    col = _get_collection()
    try:
        where: dict[str, Any]
        if package_name:
            where = {
                "$and": [
                    {"object_name":  {"$eq": object_name.upper()}},
                    {"package_name": {"$eq": package_name.upper()}},
                ]
            }
        else:
            where = {"object_name": {"$eq": object_name.upper()}}

        result = col.get(
            where=where,
            include=["documents", "metadatas"],
        )
        if result["ids"]:
            return {
                "id":          result["ids"][0],
                "explanation": result["documents"][0],
                "metadata":    result["metadatas"][0],
            }
    except Exception as exc:
        logger.error("search_by_name error: %s", exc)
    return None


def search_dependencies(
    dep_names: list[str],
    get_embedding_fn: Any,
) -> list[dict[str, Any]]:
    """
    Retrieve stored knowledge for a list of dependency identifiers.

    Strategy:
      1. Try exact name match via metadata filter.
      2. Fall back to semantic similarity search using embeddings.

    Args:
        dep_names:        List of dependency identifiers (e.g. "PKG.PROC").
        get_embedding_fn: Callable(text) → list[float] — the Ollama embed function.

    Returns:
        List of matched knowledge dicts (may be empty).
    """
    col       = _get_collection()
    found:    list[dict[str, Any]] = []
    seen_ids: set[str]             = set()

    for dep in dep_names[:15]:  # cap to avoid huge prompts
        dep_upper = dep.upper().strip()
        # Split package.object if present
        if "." in dep_upper:
            pkg_part, obj_part = dep_upper.split(".", 1)
        else:
            pkg_part, obj_part = None, dep_upper

        # ── 1. Exact name match ───────────────────────────────────────────────
        hit = search_by_name(obj_part, pkg_part)
        if hit and hit["id"] not in seen_ids:
            seen_ids.add(hit["id"])
            found.append(hit)
            continue

        # ── 2. Semantic similarity ────────────────────────────────────────────
        try:
            emb = get_embedding_fn(
                f"Oracle PL/SQL {dep_upper} procedure function package"
            )
            results = col.query(
                query_embeddings=[emb],
                n_results=_MAX_DEP_RESULTS,
                include=["documents", "metadatas", "distances"],
            )
            for i, doc_id in enumerate(results["ids"][0]):
                distance = results["distances"][0][i]
                if distance <= _DEP_DISTANCE and doc_id not in seen_ids:
                    seen_ids.add(doc_id)
                    found.append({
                        "id":          doc_id,
                        "explanation": results["documents"][0][i],
                        "metadata":    results["metadatas"][0][i],
                        "distance":    distance,
                    })
        except Exception as exc:
            logger.warning("Dependency semantic search failed for '%s': %s", dep, exc)

    return found


# ─────────────────────────────────────────────────────────────────────────────
# Write operations
# ─────────────────────────────────────────────────────────────────────────────

def upsert_knowledge(
    code_hash:        str,
    raw_code:         str,
    cleaned_code:     str,
    explanation:      str,
    metadata:         dict[str, Any],
    embedding:        list[float],
    functional_summary: str = "",
    technical_summary:  str = "",
) -> None:
    """
    Insert or update a PL/SQL knowledge document in ChromaDB.

    If a document with the same code_hash already exists it is updated
    (upsert behaviour); otherwise it is inserted as new.

    Args:
        code_hash:          SHA-256 of normalised code.
        raw_code:           Original code as pasted by the user.
        cleaned_code:       Normalised code used for hashing.
        explanation:        Full markdown reverse-engineering document.
        metadata:           Parsed metadata dict from core.parser.
        embedding:          Embedding vector for the document.
        functional_summary: Optional extracted functional summary text.
        technical_summary:  Optional extracted technical summary text.
    """
    col = _get_collection()
    now = datetime.now(timezone.utc).isoformat()

    # Check if updating (to preserve created_at)
    existing = search_by_hash(code_hash)
    created_at = existing["metadata"].get("created_at", now) if existing else now

    doc_metadata = {
        "object_name":        metadata.get("object_name", "UNKNOWN"),
        "object_type":        metadata.get("object_type", "UNKNOWN"),
        "package_name":       metadata.get("package_name") or "",
        "code_hash":          code_hash,
        "raw_code":           raw_code[:4096],       # ChromaDB metadata cap
        "cleaned_code":       cleaned_code[:4096],
        "functional_summary": functional_summary[:1024],
        "technical_summary":  technical_summary[:1024],
        "dependencies":       json.dumps(metadata.get("dependencies", [])),
        "tables_used":        json.dumps(metadata.get("tables_used",  [])),
        "created_at":         created_at,
        "updated_at":         now,
        "feedback_score":     0,
    }

    try:
        col.upsert(
            ids       =[code_hash],
            documents =[explanation],
            embeddings=[embedding],
            metadatas =[doc_metadata],
        )
        logger.info(
            "Upserted knowledge for %s '%s' (hash=%s…).",
            metadata.get("object_type", "?"),
            metadata.get("object_name", "?"),
            code_hash[:8],
        )
    except Exception as exc:
        logger.error("ChromaDB upsert failed: %s", exc)
        raise


# ─────────────────────────────────────────────────────────────────────────────
# Feedback
# ─────────────────────────────────────────────────────────────────────────────

def update_feedback(
    code_hash:   str,
    score:       int,
    correction:  str = "",
) -> bool:
    """
    Update the feedback_score (1 = thumbs-up, -1 = thumbs-down) for a stored doc.
    Appends the correction text to the explanation if provided.

    Returns True on success, False if the document was not found.
    """
    col = _get_collection()
    existing = search_by_hash(code_hash)
    if not existing:
        logger.warning("update_feedback: no document found for hash %s.", code_hash)
        return False

    meta = dict(existing["metadata"])
    meta["feedback_score"] = score
    meta["updated_at"]     = datetime.now(timezone.utc).isoformat()

    explanation = existing["explanation"]
    if correction.strip():
        explanation += f"\n\n---\n**User Correction / Feedback:**\n{correction.strip()}"

    try:
        col.upsert(
            ids       =[code_hash],
            documents =[explanation],
            embeddings=[existing["embedding"]] if existing.get("embedding") is not None else None,
            metadatas =[meta],
        )
        return True
    except Exception as exc:
        logger.error("update_feedback error: %s", exc)
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Stats
# ─────────────────────────────────────────────────────────────────────────────

def get_collection_stats() -> dict[str, Any]:
    """Return basic statistics about the knowledge base collection."""
    try:
        col   = _get_collection()
        count = col.count()

        # Fetch a sample to compute type distribution
        sample = col.get(
            limit=min(count, 200),
            include=["metadatas"],
        )
        type_counts: dict[str, int] = {}
        feedback_pos = 0
        feedback_neg = 0
        for m in sample.get("metadatas", []):
            otype = m.get("object_type", "UNKNOWN")
            type_counts[otype] = type_counts.get(otype, 0) + 1
            fb = m.get("feedback_score", 0)
            if fb == 1:
                feedback_pos += 1
            elif fb == -1:
                feedback_neg += 1

        return {
            "total":        count,
            "type_counts":  type_counts,
            "feedback_pos": feedback_pos,
            "feedback_neg": feedback_neg,
            "db_path":      _DB_PATH,
            "collection":   _COLLECTION,
        }
    except Exception as exc:
        logger.error("get_collection_stats error: %s", exc)
        return {"total": 0, "type_counts": {}, "feedback_pos": 0, "feedback_neg": 0}


def get_recent_objects(limit: int = 10) -> list[dict[str, Any]]:
    """Return the most recently stored objects (by updated_at metadata)."""
    try:
        col    = _get_collection()
        result = col.get(
            limit=min(col.count(), 200),
            include=["metadatas"],
        )
        items = []
        for i, doc_id in enumerate(result.get("ids", [])):
            m = result["metadatas"][i]
            items.append({
                "id":          doc_id,
                "object_name": m.get("object_name", "?"),
                "object_type": m.get("object_type", "?"),
                "updated_at":  m.get("updated_at",  ""),
                "feedback_score": m.get("feedback_score", 0),
            })
        # Sort by updated_at descending
        items.sort(key=lambda x: x["updated_at"], reverse=True)
        return items[:limit]
    except Exception as exc:
        logger.error("get_recent_objects error: %s", exc)
        return []


# ─────────────────────────────────────────────────────────────────────────────
# Admin / Manual Management
# ─────────────────────────────────────────────────────────────────────────────

def delete_knowledge(code_hash: str) -> bool:
    """Delete a specific object's knowledge by its hash ID."""
    col = _get_collection()
    try:
        col.delete(ids=[code_hash])
        return True
    except Exception as exc:
        logger.error("delete_knowledge error: %s", exc)
        return False

def update_knowledge_explanation(code_hash: str, new_explanation: str) -> bool:
    """Manually update the explanation text for a specific object."""
    col = _get_collection()
    existing = search_by_hash(code_hash)
    if not existing:
        return False
        
    try:
        col.update(
            ids=[code_hash],
            documents=[new_explanation],
            embeddings=[existing["embedding"]] if existing.get("embedding") is not None else None,
            metadatas=[existing["metadata"]]
        )
        return True
    except Exception as exc:
        logger.error("update_knowledge_explanation error: %s", exc)
        return False

def reset_collection() -> bool:
    """Delete the entire ChromaDB collection."""
    global _collection
    try:
        # Re-initialize client if missing
        if _client is None:
            _get_collection()
            
        _client.delete_collection(name=_COLLECTION)
        _collection = None  # Force recreation on next use
        return True
    except Exception as exc:
        logger.error("reset_collection error: %s", exc)
        return False
