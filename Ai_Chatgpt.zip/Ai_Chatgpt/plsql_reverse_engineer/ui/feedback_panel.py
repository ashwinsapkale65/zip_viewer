"""
ui/feedback_panel.py
---------------------
Thumbs-up / thumbs-down feedback widget for reverse engineering results.

Each feedback form is keyed by code_hash so multiple results in the
same session each have independent state.
"""

import streamlit as st
from services.feedback_service import submit_feedback, get_feedback_summary


def render_feedback_form(code_hash: str, key_suffix: str = "") -> None:
    """
    Render a compact feedback bar below a reverse-engineering result.

    State is stored in st.session_state under 'feedback_<code_hash>'
    to prevent re-rendering issues across Streamlit reruns.

    Args:
        code_hash: SHA-256 hash of the processed code (ChromaDB document ID).
        key_suffix: Unique suffix to prevent duplicate widget keys if rendered multiple times.
    """
    state_key = f"feedback_{code_hash}"
    suffix = key_suffix if key_suffix else code_hash

    # Initialise state if not present
    if state_key not in st.session_state:
        existing = get_feedback_summary(code_hash)
        st.session_state[state_key] = {
            "submitted":  existing["score"] != 0,
            "score":      existing["score"],
            "show_form":  False,
            "message":    "",
        }

    fb_state = st.session_state[state_key]

    st.markdown('<div class="feedback-bar">', unsafe_allow_html=True)

    if fb_state["submitted"]:
        # Already submitted — show summary
        icon  = "👍" if fb_state["score"] == 1 else "👎"
        label = "Positive" if fb_state["score"] == 1 else "Negative"
        st.markdown(
            f'<span class="feedback-done">{icon} Feedback recorded — {label}</span>',
            unsafe_allow_html=True,
        )
    else:
        # Feedback prompt
        st.markdown(
            '<span class="feedback-prompt">Was this explanation helpful?</span>',
            unsafe_allow_html=True,
        )
        col1, col2, col3 = st.columns([1, 1, 8])

        with col1:
            if st.button(
                "👍",
                key=f"up_{suffix}",
                help="This explanation is accurate and useful.",
            ):
                fb_state["score"]     = 1
                fb_state["show_form"] = True
                # Instantly save the generic thumbs up signal
                submit_feedback(code_hash=code_hash, thumbs_up=True)

        with col2:
            if st.button(
                "👎",
                key=f"down_{suffix}",
                help="This explanation has errors or is incomplete.",
            ):
                fb_state["score"]     = -1
                fb_state["show_form"] = True
                # Instantly save the generic thumbs down signal
                submit_feedback(code_hash=code_hash, thumbs_up=False)

    # Show correction form after thumbs action
    if fb_state.get("show_form") and not fb_state["submitted"]:
        with st.container():
            correction = st.text_area(
                "Optional: Describe the issue or provide a correction",
                key=f"correction_{suffix}",
                height=80,
                placeholder="e.g. Missing explanation for the cursor loop on line 42…",
            )
            sub_col1, sub_col2 = st.columns([1, 6])
            with sub_col1:
                if st.button("Submit", key=f"submit_{suffix}", type="primary"):
                    result = submit_feedback(
                        code_hash  = code_hash,
                        thumbs_up  = (fb_state["score"] == 1),
                        correction = correction,
                    )
                    fb_state["submitted"] = True
                    fb_state["show_form"] = False
                    fb_state["message"]   = result["message"]
                    st.rerun()
            with sub_col2:
                if st.button("Skip", key=f"skip_{suffix}"):
                    # Already saved initially, just mark as completed on UI
                    fb_state["submitted"] = True
                    fb_state["show_form"] = False
                    st.rerun()

    # Show confirmation toast
    if fb_state.get("message") and fb_state["submitted"]:
        st.success(fb_state["message"], icon="✅")
        fb_state["message"] = ""   # clear after one render

    st.markdown("</div>", unsafe_allow_html=True)
