"""
ui/admin_panel.py
-----------------
Admin panel for managing the ChromaDB knowledge base.
Provides functionality to:
- Reset entire collection
- Edit object explanations
- Delete specific objects
Locked behind ADMIN_PASSWORD from .env.
"""

import os
import streamlit as st
from services import chromadb_service

def render_admin_panel() -> None:
    st.markdown("### 🛠️ Admin & Knowledge Management")
    
    admin_pw = os.getenv("ADMIN_PASSWORD", "")
    
    # ── Authentication ────────────────────────────────────────────────────────
    if not st.session_state.get("admin_unlocked", False):
        if not admin_pw:
            st.warning("`ADMIN_PASSWORD` is not set in your `.env` file. Admin features are disabled.")
            return

        st.info("Enter admin password to manage knowledge base.")
        with st.form("admin_login"):
            pw_input = st.text_input("Admin Password", type="password")
            submitted = st.form_submit_button("Unlock Admin")
            if submitted:
                if pw_input == admin_pw:
                    st.session_state.admin_unlocked = True
                    st.rerun()
                else:
                    st.error("Incorrect password")
        return

    # ── Admin Panel Unlocked ──────────────────────────────────────────────────
    if st.button("🔒 Lock Admin", use_container_width=True):
        st.session_state.admin_unlocked = False
        st.rerun()

    st.markdown("---")

    st.markdown("**📝 Edit / Delete Specific Objects**")
    recent = chromadb_service.get_recent_objects(limit=1000)
    
    if not recent:
        st.info("No objects in knowledge base.")
    else:
        search_q = st.text_input("🔍 Search by object name...", placeholder="e.g. UPDATE_CUSTOMER").strip().lower()
        
        filtered = []
        for o in recent:
            if not search_q or search_q in o['object_name'].lower() or search_q in o['object_type'].lower():
                filtered.append(o)
                
        if not filtered:
            st.warning("No objects match your search.")
        else:
            obj_options = {
                f"{o['object_name']} ({o['object_type']}) - {o['id'][:8]}": o["id"] 
                for o in filtered
            }
            selected_label = st.selectbox("Select object to manage:", list(obj_options.keys()))
        
        if selected_label:
            code_hash = obj_options[selected_label]
            doc = chromadb_service.search_by_hash(code_hash)
            
            if doc:
                with st.expander("✏️ Edit Explanation Markdown", expanded=True):
                    new_expl = st.text_area(
                        "Explanation", 
                        value=doc["explanation"], 
                        height=400, 
                        key=f"edit_{code_hash}"
                    )
                    if st.button("💾 Save Changes", key=f"save_{code_hash}", type="primary"):
                        if chromadb_service.update_knowledge_explanation(code_hash, new_expl):
                            st.success("Successfully updated explanation!")
                        else:
                            st.error("Failed to update.")
                            
                if st.button("🗑️ Delete Object", key=f"del_{code_hash}", use_container_width=True):
                    if chromadb_service.delete_knowledge(code_hash):
                        st.session_state.stats_cache = None
                        st.success(f"Deleted {selected_label}.")
                        st.rerun()
                    else:
                        st.error("Failed to delete.")
            else:
                st.error("Could not retrieve document from ChromaDB. Background service error.")

    st.markdown("---")
    
    # 2. Reset Entire DB
    st.markdown("**🗑️ Danger Zone**")
    st.warning("Resetting the collection will permanently delete all stored PL/SQL knowledge!")
    
    with st.expander("Reset Knowledge Base"):
        st.markdown("Are you entirely sure? This cannot be undone.")
        if st.button("🚨 CONFIRM RESET ENTIRE DATABASE", type="primary"):
            if chromadb_service.reset_collection():
                st.session_state.stats_cache = None
                st.success("ChromaDB collection has been reset.")
                st.rerun()
            else:
                st.error("Failed to reset collection.")
