"""
core/classifier.py
------------------
Classifies user input as: 'plsql', 'mixed', or 'chat'.
Uses regex heuristics on Oracle PL/SQL syntactic markers.
"""

import re
from typing import Literal

InputType = Literal["plsql", "mixed", "chat"]

# ── Strong PL/SQL block markers ──────────────────────────────────────────────
_BLOCK_PATTERNS: list[str] = [
    r"\bCREATE\s+(?:OR\s+REPLACE\s+)?(?:PROCEDURE|FUNCTION|PACKAGE|TRIGGER|TYPE|VIEW)\b",
    r"\bDECLARE\b",
    r"\bBEGIN\b",
    r"\bEND\s*;",
    r"\bEND\s+\w+\s*;",
    r"\bIS\s*\n",
    r"\bAS\s*\n",
    r"%ROWTYPE\b",
    r"%TYPE\b",
    r"\bCURSOR\s+\w+\s+IS\b",
    r"\bEXCEPTION\b",
    r"\bRAISE(?:_APPLICATION_ERROR)?\b",
    r"\bPRAGMA\b",
    r"\bCOMMIT\s*;",
    r"\bROLLBACK\s*;",
    r"\bFOR\s+\w+\s+IN\s*(?:\(|SELECT|\w+)",
    r"\bOPEN\s+\w+\s*(?:FOR\b|\()",
    r"\bFETCH\s+\w+\s+INTO\b",
    r"\bCLOSE\s+\w+\s*;",
    r"\bEXIT\s+WHEN\b",
    r"\bDBMS_OUTPUT\s*\.",
    r"\bSQLCODE\b",
    r"\bSQLERRM\b",
    r"\bSQL%ROWCOUNT\b",
    r"\bSYSDATE\b",
    r"\bNVL\s*\(",
    r"\bDECODE\s*\(",
    r"\bTO_CHAR\s*\(",
    r"\bTO_DATE\s*\(",
]

_BLOCK_RE = re.compile(
    "|".join(_BLOCK_PATTERNS),
    flags=re.IGNORECASE | re.MULTILINE,
)

# Minimum number of matches to be considered PL/SQL
_PLSQL_THRESHOLD = 2


def classify_input(text: str) -> InputType:
    """
    Classify user input as one of: 'plsql', 'mixed', 'chat'.

    Args:
        text: Raw user input string.

    Returns:
        'plsql'  – the message is entirely / predominantly PL/SQL code.
        'mixed'  – the message contains both conversational text and PL/SQL.
        'chat'   – purely conversational text.
    """
    if not text or not text.strip():
        return "chat"

    matches = _BLOCK_RE.findall(text)
    hit_count = len(matches)

    if hit_count == 0:
        return "chat"

    # Heuristic: if >60 % of non-blank lines look like code, treat as plsql
    non_blank_lines = [ln for ln in text.splitlines() if ln.strip()]
    total_lines = max(len(non_blank_lines), 1)

    # Count lines containing any PL/SQL marker
    code_lines = sum(
        1 for ln in non_blank_lines if _BLOCK_RE.search(ln)
    )
    code_ratio = code_lines / total_lines

    if hit_count >= _PLSQL_THRESHOLD and code_ratio >= 0.3:
        if code_ratio >= 0.6:
            return "plsql"
        return "mixed"

    if hit_count >= _PLSQL_THRESHOLD:
        return "mixed"

    return "chat"


def extract_code_block(text: str) -> tuple[str, str]:
    """
    Split a mixed message into (conversational_part, code_part).

    For purely PL/SQL input, conversational_part is empty.
    For chat input, code_part is empty.

    Returns:
        (conversational_text, plsql_code)
    """
    # Look for fenced code blocks first
    fenced = re.search(
        r"```(?:sql|plsql|oracle)?\s*\n(.*?)```",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )
    if fenced:
        code = fenced.group(1).strip()
        chat_part = text[: fenced.start()].strip() + " " + text[fenced.end() :].strip()
        return chat_part.strip(), code

    # Heuristic split: find the first line that looks like a PL/SQL header
    lines = text.splitlines()
    split_idx = None
    for i, line in enumerate(lines):
        if _BLOCK_RE.search(line):
            split_idx = i
            break

    if split_idx is None:
        return text.strip(), ""

    chat_part = "\n".join(lines[:split_idx]).strip()
    code_part = "\n".join(lines[split_idx:]).strip()
    return chat_part, code_part
