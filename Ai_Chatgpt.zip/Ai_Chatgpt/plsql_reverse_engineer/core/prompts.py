"""
core/prompts.py
---------------
All LLM prompt templates for the PL/SQL Reverse Engineer application.
"""

from typing import Any

# ── System prompt sent once per conversation ──────────────────────────────────
SYSTEM_PROMPT = """You are an expert Oracle PL/SQL reverse engineering specialist and technical documentation writer.

Your role is to analyze Oracle PL/SQL source code and produce complete, accurate, well-structured reverse engineering documents in simple English.

Core rules you must ALWAYS follow:
- Code is the primary source of truth. Metadata must never override what is present in the code.
- Always extract dependencies from the code itself.
- Do not rely on metadata statements that claim no dependencies exist.
- If a procedure or function call appears in the code, list it under Dependencies.
- Explain how that dependency contributes to the procedure logic.
- Only mention tables and objects that appear in the code.
- Never output statements like "There are no dependencies" unless the code analysis confirms that no calls exist.
- If metadata conflicts with code, ignore metadata.
- Never skip any code step, no matter how small.
- Never invent tables, columns, parameters, or objects that are not visible in the provided code or context.
- When dependency knowledge is provided, use it to enrich your explanation of the current code.
- Write in clear, simple English that both business and technical audiences can understand.
- Format ALL output in well-structured Markdown with proper headings, bullet points, and code snippets where helpful.
- Be thorough — incomplete explanations are not acceptable.
"""

# ── Core 15-section reverse engineering prompt ────────────────────────────────
_RE_TEMPLATE = """\
## Task
Perform a complete reverse engineering analysis of the Oracle PL/SQL code below.
You are an Oracle PL/SQL reverse engineering expert.
Analyze the PL/SQL code provided.

Important rules:
1. Always extract dependencies from the code itself.
2. Do not rely on metadata statements that claim no dependencies exist.
3. If a procedure or function call appears in the code, list it under Dependencies.
4. Explain how that dependency contributes to the procedure logic.
5. Only mention tables and objects that appear in the code.
6. The system must never output statements like: "There are no dependencies" unless the code analysis confirms that no calls exist.
7. If metadata conflicts with code, ignore metadata.
8. ABSOLUTELY DO NOT output any of the prompt instructions in your final response. The user must only see the headings and your generated content.

## Explanations for each section (DO NOT output these instructions in your response):
- For "Object Type", state the exact PL/SQL object type.
- For "Object Name", state the exact object name.
- For "Purpose", explain in 2-4 sentences what the code is designed to do at a business level.
- For "Input Parameters", list and explain every IN, OUT, IN OUT parameter with data type and purpose.
- For "Variables and Declarations", explain every declared variable, constant, cursor, type, and exception.
- For "Step-by-Step Logic", walk through EVERY executable step in exact execution order. Number each step.
- For "Database Operations", describe every SELECT, INSERT, UPDATE, DELETE, and MERGE statement.
- For "Tables Used", list every table, view, sequence, synonym, or DB link referenced.
- For "Dependencies", list all called procedures, functions, packages, and utilities. Explain how they contribute.
- For "Exception Handling", explain every EXCEPTION block.
- For "Functional Summary", write a 3-5 sentence business-level summary.
- For "Technical Summary", write a 3-5 sentence developer-level summary.
- For "Performance / Risk Notes", identify any clear performance concerns or risk factors.

---

## Extracted Metadata
- **Object Type:** {object_type}
- **Object Name:** {object_name}
- **Package / Schema:** {package_name}
- **Identified Dependencies:** {dependencies}
- **Tables / Views Detected:** {tables_used}

---

## Dependency Knowledge from Knowledge Base
{dep_context}

---

## PL/SQL Code to Analyze
```sql
{code}
```

---

## Required Output Format — USE EXACTLY THESE HEADINGS AND NO INSTRUCTION TEXT:

### 1. Object Type
### 2. Object Name
### 3. Purpose
### 4. Input Parameters
### 5. Variables and Declarations
### 6. Step-by-Step Logic
### 7. Database Operations
### 8. Tables Used
### 9. Conditions and Branching
### 10. Loops and Cursors
### 11. Exception Handling
### 12. Dependencies
### 13. Functional Summary
### 14. Technical Summary
### 15. Performance / Risk Notes

---
End of analysis.
"""


def build_reverse_engineer_prompt(
    code: str,
    metadata: dict[str, Any],
    dep_context: list[dict[str, Any]],
) -> str:
    """
    Build the complete user-turn prompt for the reverse engineering LLM call.

    Args:
        code:        Raw PL/SQL source text.
        metadata:    Parsed metadata dict from core.parser.
        dep_context: List of ChromaDB knowledge dicts for dependency objects.

    Returns:
        Formatted prompt string ready to be sent as the user message.
    """
    # Format dependency context
    if dep_context:
        dep_sections: list[str] = []
        for i, dep in enumerate(dep_context, start=1):
            meta = dep.get("metadata", {})
            name = meta.get("object_name", "Unknown")
            otype = meta.get("object_type", "Unknown")
            expl = dep.get("explanation", "No details available.")
            # Truncate long explanations to keep the prompt manageable
            if len(expl) > 2000:
                expl = expl[:2000] + "\n… [truncated for brevity]"
            dep_sections.append(
                f"**Dependency {i}: {name} ({otype})**\n{expl}"
            )
        dep_context_str = "\n\n---\n\n".join(dep_sections)
    else:
        dep_context_str = (
            "_No prior knowledge found in the knowledge base for the detected dependencies._\n"
            "Analyze the current code on its own merits."
        )

    # Format metadata fields
    return _RE_TEMPLATE.format(
        object_type  = metadata.get("object_type",  "UNKNOWN"),
        object_name  = metadata.get("object_name",  "UNKNOWN"),
        package_name = metadata.get("package_name") or "N/A",
        dependencies = ", ".join(metadata.get("dependencies", [])) or "None detected",
        tables_used  = ", ".join(metadata.get("tables_used",  [])) or "None detected",
        dep_context  = dep_context_str,
        code         = code.strip(),
    )


def build_chat_system_prompt() -> str:
    """
    System prompt for normal conversational chat (non-PL/SQL messages).
    """
    return (
        "You are a knowledgeable Oracle database and PL/SQL expert assistant. "
        "Answer questions clearly and concisely. "
        "When asked about PL/SQL concepts, give practical examples. "
        "If the user pastes code, offer to run a full reverse engineering analysis."
    )
