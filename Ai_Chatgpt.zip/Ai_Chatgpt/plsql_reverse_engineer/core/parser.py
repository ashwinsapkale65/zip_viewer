"""
core/parser.py
--------------
Heuristic PL/SQL parser that extracts:
  - Top-level object type and name
  - Package name (if applicable)
  - Called dependencies (procedures / functions / packages)
  - Tables and views referenced in DML statements
"""

import re
from typing import Any

# ── Oracle built-ins / keywords to EXCLUDE from dependency list ───────────────
_ORACLE_BUILTINS: set[str] = {
    # Output / file
    "DBMS_OUTPUT", "UTL_FILE", "UTL_HTTP", "UTL_MAIL", "UTL_RAW",
    "UTL_TCP", "UTL_SMTP",
    # SQL / meta
    "DBMS_SQL", "DBMS_UTILITY", "DBMS_DDL", "DBMS_METADATA",
    "DBMS_SESSION", "DBMS_APPLICATION_INFO",
    "DBMS_LOB", "DBMS_XMLGEN", "DBMS_SCHEDULER",
    "DBMS_PIPE", "DBMS_ALERT", "DBMS_LOCK",
    "DBMS_STATS", "DBMS_XPLAN",
    # System schemas
    "SYS", "SYSTEM", "STANDARD", "MDSYS", "CTXSYS", "XDB",
    # Scalar functions (just the package part if they appear as pkg.fn)
    "TO_CHAR", "TO_DATE", "TO_NUMBER", "TO_TIMESTAMP",
    "NVL", "NVL2", "DECODE", "COALESCE", "NULLIF",
    "SUBSTR", "INSTR", "TRIM", "LTRIM", "RTRIM",
    "UPPER", "LOWER", "INITCAP", "LENGTH", "LPAD", "RPAD",
    "REPLACE", "TRANSLATE", "REGEXP_REPLACE", "REGEXP_SUBSTR",
    "REGEXP_LIKE", "REGEXP_INSTR", "REGEXP_COUNT",
    "ROUND", "TRUNC", "CEIL", "FLOOR", "MOD", "ABS", "SIGN",
    "POWER", "SQRT", "EXP", "LN", "LOG",
    "SYSDATE", "SYSTIMESTAMP", "CURRENT_DATE",
    "CURRENT_TIMESTAMP", "LOCALTIMESTAMP",
    "ADD_MONTHS", "MONTHS_BETWEEN", "LAST_DAY", "NEXT_DAY",
    "EXTRACT", "NUMTODSINTERVAL", "NUMTOYMINTERVAL",
    "COUNT", "SUM", "AVG", "MIN", "MAX", "LISTAGG",
    "ROW_NUMBER", "RANK", "DENSE_RANK", "NTILE",
    "LAG", "LEAD", "FIRST_VALUE", "LAST_VALUE",
    "ROLLUP", "CUBE", "GROUPING",
    "RAISE_APPLICATION_ERROR", "SQLCODE", "SQLERRM",
    "SQL",          # SQL%ROWCOUNT etc.
    "NEW", "OLD",   # trigger pseudo-rows
    "V", "NLS",
    # XML
    "XMLELEMENT", "XMLFOREST", "XMLAGG", "XMLTYPE",
    "XMLQUERY", "XMLTABLE", "XMLROOT", "XMLPARSE",
}

# ── SQL keywords that appear after FROM/JOIN but are NOT table names ──────────
_SQL_NON_TABLES: set[str] = {
    "DUAL", "WHERE", "SET", "VALUES", "SELECT", "INTO", "FROM",
    "TABLE", "VIEW", "INDEX", "ON", "USING", "LATERAL",
    "CROSS", "INNER", "LEFT", "RIGHT", "OUTER", "FULL",
    "NATURAL", "STRAIGHT", "JOIN", "WITH",
    "AS", "CASE", "WHEN", "THEN", "ELSE", "END",
    "GROUP", "ORDER", "BY", "HAVING", "LIMIT",
}

# ── Standard PL/SQL keywords that might precede parentheses ───────────────────
_PLSQL_KEYWORDS: set[str] = {
    "IF", "ELSIF", "WHILE", "FOR", "RETURN", "EXIT", "IN", "AND", "OR", "NOT",
    "CAST", "TREAT", "TRIM", "EXISTS", "IS", "NULL", "TRUE", "FALSE", "WHEN",
    "THEN", "ELSE", "END", "DECLARE", "BEGIN", "EXCEPTION"
}

# ── Regexes for object header ─────────────────────────────────────────────────
_HDR_PROCEDURE   = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+([\w.]+)",
    re.IGNORECASE,
)
_HDR_FUNCTION    = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+([\w.]+)",
    re.IGNORECASE,
)
_HDR_PKG_BODY    = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+BODY\s+(\w+)",
    re.IGNORECASE,
)
_HDR_PACKAGE     = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+(?!BODY\b)(\w+)",
    re.IGNORECASE,
)
_HDR_TRIGGER     = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:EDITIONABLE\s+)?TRIGGER\s+(\w+)",
    re.IGNORECASE,
)
_HDR_TYPE        = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?TYPE\s+(?!BODY\b)(\w+)",
    re.IGNORECASE,
)
_HDR_TYPE_BODY   = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?TYPE\s+BODY\s+(\w+)",
    re.IGNORECASE,
)

# ── Dependency regexes ────────────────────────────────────────────────────────
# package.object(  OR  schema.pkg.obj(  OR  standalone_obj(
_CALL_RE         = re.compile(
    r"\b([a-zA-Z_][a-zA-Z0-9_$]*)(?:\.([a-zA-Z_][a-zA-Z0-9_$]*))?\s*\(",
    re.IGNORECASE,
)
# EXEC[UTE] obj  OR  EXEC[UTE] pkg.obj
_EXEC_RE         = re.compile(
    r"\bEXECUTE?\s+([\w.]+)\s*(?=\(|;|\s|$)",
    re.IGNORECASE,
)

# ── DML table/view extraction ─────────────────────────────────────────────────
_FROM_RE   = re.compile(r"\bFROM\s+([\w$#]+)", re.IGNORECASE)
_JOIN_RE   = re.compile(r"\bJOIN\s+([\w$#]+)",  re.IGNORECASE)
_INSERT_RE = re.compile(r"\bINSERT\s+INTO\s+([\w$#]+)", re.IGNORECASE)
_UPDATE_RE = re.compile(r"\bUPDATE\s+([\w$#]+)", re.IGNORECASE)
_DELETE_RE = re.compile(r"\bDELETE\s+FROM\s+([\w$#]+)", re.IGNORECASE)
_MERGE_RE  = re.compile(r"\bMERGE\s+INTO\s+([\w$#]+)", re.IGNORECASE)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_object_metadata(code: str) -> dict[str, Any]:
    """
    Parse a PL/SQL code block and return structured metadata.

    Returns:
        {
          "object_type":  str,        # PROCEDURE | FUNCTION | PACKAGE BODY | …
          "object_name":  str,        # bare name in UPPER CASE
          "package_name": str | None, # schema/package prefix if present
          "dependencies": list[str],  # called objects (unique, sorted)
          "tables_used":  list[str],  # DML tables/views (unique, sorted)
        }
    """
    object_type = "ANONYMOUS BLOCK"
    object_name = "ANONYMOUS_BLOCK"
    package_name: str | None = None

    # Try each header pattern in priority order
    for pattern, otype in [
        (_HDR_PROCEDURE,  "PROCEDURE"),
        (_HDR_FUNCTION,   "FUNCTION"),
        (_HDR_PKG_BODY,   "PACKAGE BODY"),
        (_HDR_PACKAGE,    "PACKAGE"),
        (_HDR_TRIGGER,    "TRIGGER"),
        (_HDR_TYPE_BODY,  "TYPE BODY"),
        (_HDR_TYPE,       "TYPE"),
    ]:
        m = pattern.search(code)
        if m:
            object_type = otype
            full_name = m.group(1).upper()
            if "." in full_name:
                parts = full_name.split(".", 1)
                package_name = parts[0]
                object_name  = parts[1]
            else:
                object_name = full_name
            break

    dependencies = _extract_dependencies(code)
    tables       = _extract_tables(code)

    return {
        "object_type":  object_type,
        "object_name":  object_name,
        "package_name": package_name,
        "dependencies": dependencies,
        "tables_used":  tables,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _extract_dependencies(code: str) -> list[str]:
    """Extract called procedures/functions/packages, excluding Oracle built-ins."""
    found: set[str] = set()

    # Procedure/function calls: pkg.obj( ... ) OR standalone( ... )
    for m in _CALL_RE.finditer(code):
        part1 = m.group(1).upper()
        part2 = m.group(2).upper() if m.group(2) else None

        if part2:
            # Package or schema-qualified call
            if part1 not in _ORACLE_BUILTINS and part2 not in _ORACLE_BUILTINS:
                found.add(f"{part1}.{part2}")
        else:
            # Standalone procedure/function call
            if (part1 not in _ORACLE_BUILTINS and 
                part1 not in _SQL_NON_TABLES and 
                part1 not in _PLSQL_KEYWORDS):
                found.add(part1)

    # EXEC / EXECUTE references
    for m in _EXEC_RE.finditer(code):
        ref = m.group(1).upper().strip(".")
        parts = ref.split(".")
        # skip if any part is a known built-in
        if not any(p in _ORACLE_BUILTINS for p in parts):
            found.add(ref)

    return sorted(found)


def _extract_tables(code: str) -> list[str]:
    """Extract table/view names referenced in DML statements."""
    found: set[str] = set()

    for pattern in (_FROM_RE, _JOIN_RE, _INSERT_RE, _UPDATE_RE, _DELETE_RE, _MERGE_RE):
        for m in pattern.finditer(code):
            name = m.group(1).upper()
            if name not in _SQL_NON_TABLES and not name.startswith("V("):
                found.add(name)

    return sorted(found)


def parse_dependency_name(dep: str) -> tuple[str | None, str]:
    """
    Split a dependency string into (package_name, object_name).

    Examples:
        "PKG_UTIL.LOG_ERROR" → ("PKG_UTIL", "LOG_ERROR")
        "GET_EMPLOYEE"        → (None, "GET_EMPLOYEE")
    """
    if "." in dep:
        parts = dep.split(".", 1)
        return parts[0].upper(), parts[1].upper()
    return None, dep.upper()
