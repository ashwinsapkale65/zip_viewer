"""
core/hasher.py
--------------
Utilities for normalising and hashing PL/SQL code.
A SHA-256 hash of the normalised code is used as
the primary cache key in ChromaDB.
"""

import hashlib
import re


# ── Oracle single-line comment ────────────────────────────────────────────────
_SINGLE_COMMENT_RE = re.compile(r"--[^\n]*")

# ── Oracle / SQL multi-line comment ──────────────────────────────────────────
_MULTI_COMMENT_RE = re.compile(r"/\*.*?\*/", flags=re.DOTALL)

# ── Consecutive whitespace (spaces, tabs, newlines) ──────────────────────────
_WHITESPACE_RE = re.compile(r"\s+")


def clean_code(code: str) -> str:
    """
    Normalise PL/SQL code for consistent hashing and storage.

    Steps:
      1. Strip single-line comments  (-- …)
      2. Strip multi-line comments   (/* … */)
      3. Collapse all whitespace to a single space
      4. Upper-case everything
      5. Strip leading/trailing whitespace

    Args:
        code: Raw PL/SQL source text.

    Returns:
        Normalised, comment-free, upper-cased version of the code.
    """
    code = _SINGLE_COMMENT_RE.sub("", code)
    code = _MULTI_COMMENT_RE.sub("", code)
    code = _WHITESPACE_RE.sub(" ", code)
    return code.strip().upper()


def compute_hash(code: str) -> str:
    """
    Compute a SHA-256 hex digest of the normalised PL/SQL code.

    This hash is used as the ChromaDB document ID and for
    exact-match cache lookups so that identical code is never
    processed twice.

    Args:
        code: Raw PL/SQL source text (will be normalised internally).

    Returns:
        64-character lowercase hex string.
    """
    normalised = clean_code(code)
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()


def short_hash(code: str, length: int = 8) -> str:
    """
    Return the first *length* characters of the full SHA-256 hash.
    Useful for display purposes in the UI.
    """
    return compute_hash(code)[:length].upper()
