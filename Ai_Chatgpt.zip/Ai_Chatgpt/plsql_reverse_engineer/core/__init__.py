# Core package — classifier, parser, hasher, prompts
